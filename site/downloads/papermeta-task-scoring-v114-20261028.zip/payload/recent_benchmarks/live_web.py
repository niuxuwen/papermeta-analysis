"""Read-only live projection and HTTP UI; workers own all persistent state.

``build_snapshot`` consumes detached job records, each optionally containing
``result={catalog: [...], observations: [...], enrichment: {items: [...]}}``.
Those inputs must already have passed the extraction/reporting evidence gates.
This module reapplies the moving time window and cross-run identity gates; it
never upgrades a review decision or infers a release date. The provider passed
to ``make_server`` must read its store consistently and use the current clock
on every invocation. No run directory or arbitrary file is served here.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import gzip
import base64
import math
import re
import threading
from urllib.parse import parse_qs, parse_qsl, unquote, urlsplit

from .indexing import build_index
from .window_policy import DEFAULT_WINDOW_DAYS, DEFAULT_BENCHMARK_MONTHS, benchmark_window
from .source_issues import blocking_source_issues
from .taxonomy import TAXONOMY, TAXONOMY_VERSION, SUPPORTED_TAXONOMY_VERSIONS
from .task_labels import ANNOTATION_VERSION, BUILTIN_PROFILES, group_id_for
from .task_workspace_page import PAGE as TASK_WORKSPACE_PAGE
from .capability_atlas_page import page_with_atlas, page_with_catalog_facets
TASK_WORKSPACE_PAGE = page_with_atlas(TASK_WORKSPACE_PAGE)
from .snapshot_publication import SnapshotNotReady


_CATALOG_TEXT = (
    "benchmark_id", "benchmark_name", "paper_id", "arxiv_id", "paper_title",
    "paper_first_published", "release_date", "date_basis", "eligibility",
    "status", "evidence_quote", "history_status", "admission_basis",
    "qualification_scope",
)
_OBSERVATION_TEXT = (
    "observation_id", "benchmark_id", "paper_id", "paper_title", "table_id",
    "row_key", "benchmark", "metric", "direction", "model_raw",
    "model_canonical", "model_setting", "comparison_key", "value_raw",
    "benchmark_release_date", "date_basis", "scope_evidence", "model_kind",
    "base_model_evidence", "model_admission_basis", "model_origin", "execution_mode",
    "benchmark_identity",
    "source_model_setting", "model_identity_status",
)
_NUMERIC_FIELDS = ("value_numeric", "source_row", "source_column", "source_value_slot", "confidence")
_PRIVATE_KEYS = re.compile(r"(?:api.?key|password|secret|(?:^|_)(?:access_|refresh_)?token$|authorization|credential|traceback|(?:^|_)path$|(?:^|_)dir$|headers|environment|payload)", re.I)
_PRIVATE_TEXT = re.compile(
    r"(?i)(?:\b[A-Z]:[\\/]|\\\\|file://|/(?:home|Users|tmp|private|mnt|workspace|root|etc|var|opt|usr|srv)/)"
    r"|(?:api[_ -]?key|authorization|password|access[_ -]?token|secret)\s*[:=]"
    r"|\bBearer\s+\S+|\bsk-[A-Za-z0-9_-]{12,}|Traceback \(most recent call last\)"
)
_REASONS = {
    "QUEUED": "等待处理", "PENDING": "等待处理", "RUNNING": "正在处理",
    "PROCESSING": "正在处理", "RETRY": "等待重试", "RETRY_WAIT": "等待重试",
    "FAILED": "处理失败，等待重试或检查本地日志", "ERROR": "处理失败，等待检查",
    "COMPLETE": "处理完成", "COMPLETED": "处理完成", "SUCCEEDED": "处理完成",
    "REVIEW": "证据不足，待复核", "EXCLUDED": "证据审核未通过纳入条件",
    "ELIGIBLE": "已通过证据核验且位于当前窗口",
    "NO_TABLES": "未提取到可用成绩表", "NOT_ASSESSED": "尚未完成审核",
    "REVIEW_DATE_BOUNDARY": "日期只有天粒度，跨越滚动窗口边界，待核实具体时间",
    "REVIEW_PUBLICATION_DATE": "论文首次公开日期不明确，待复核",
    "REVIEW_RELEASE_DATE": "benchmark 首次公开日期不明确，待复核",
    "REVIEW_DUPLICATE_IDENTITY": "benchmark 身份存在重复或冲突，待复核",
    "REVIEW_OBSERVATION_CONFLICT": "同一观测标识存在不同来源或内容，待复核",
    "REVIEW_RESULT_INVALID": "结果结构无效，等待重新核验",
}


def _text(value, limit=4000):
    if not isinstance(value, str):
        return ""
    if _PRIVATE_TEXT.search(value):
        return "[私有信息已省略]"
    return "".join(c for c in value if c >= " " or c in "\n\t")[:limit]


def _public(value):
    """Defense in depth for generated scorer output, never raw error objects."""
    if isinstance(value, dict):
        return {str(key): _public(item) for key, item in value.items()
                if isinstance(key, str) and not _PRIVATE_KEYS.search(key)}
    if isinstance(value, (tuple, list)):
        return [_public(item) for item in value]
    if isinstance(value, str):
        return _text(value)
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    return None


def _url(value):
    if not isinstance(value, str) or _PRIVATE_TEXT.search(value):
        return ""
    try:
        parsed = urlsplit(value)
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username or parsed.password
                or any(_PRIVATE_KEYS.search(key) for key, _ in parse_qsl(parsed.query))):
            return ""
        return value[:4096]
    except ValueError:
        return ""


def _code(value, default="UNKNOWN"):
    return value.upper() if isinstance(value, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", value) else default


def _reason(status):
    if status in _REASONS:
        return _REASONS[status]
    if "FAIL" in status or "ERROR" in status:
        return _REASONS["FAILED"]
    if "REVIEW" in status:
        return _REASONS["REVIEW"]
    return "状态待确认"


def _utc(value):
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("an explicit timezone is required")
    return value.astimezone(timezone.utc)


def _iso(value):
    return value.isoformat().replace("+00:00", "Z")


def _window_state(value, start, end):
    """A day-only date represents an interval, not invented midnight precision."""
    try:
        if isinstance(value, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            lower = datetime.fromisoformat(value).replace(tzinfo=timezone.utc)
            upper = lower + timedelta(days=1)
            if upper <= start or lower >= end:
                return "OUTSIDE"
            return "INSIDE" if lower >= start and upper <= end else "BOUNDARY"
        instant = _utc(value)
        return "INSIDE" if start <= instant < end else "OUTSIDE"
    except (TypeError, ValueError, OverflowError):
        return "UNKNOWN"


def _enrichment(item):
    """Expose evidence claims, never reviewer credentials or transport errors."""
    result = {"labels": {"status": "PENDING", "domains": [], "tasks": [], "modalities": [], "capabilities": []},
              "assets": {"status": "PENDING", "items": []}}
    if not isinstance(item, dict):
        return result
    labels = item.get("labels", {})
    labels = labels.get("result") if isinstance(labels, dict) else None
    if isinstance(labels, dict):
        from .catalog_label_state import label_summary
        summary = label_summary(labels)
        result["labels"] = {
            "status": summary["status"], "supported": summary["supported"],
            "reason": _text(labels.get('reason'), 2000),
            **{key: [_text(v, 100) for v in labels.get(key, []) if isinstance(v, str)]
               for key in ("domains", "tasks", "modalities", "capabilities") if isinstance(labels.get(key, []), list)},
            "issues": [{"code": _code(i.get('code')), "layer": _text(i.get('layer'), 40),
                        "id": _text(i.get('id'), 100), "reason": _text(i.get('reason'), 600),
                        "chunk": i.get('chunk') if type(i.get('chunk')) is int else None}
                       for i in labels.get('issues', []) if isinstance(i, dict)]
                      if isinstance(labels.get('issues'), list) else [],
            "evidence": [{"layer": _code(e.get('layer')).lower(), "id": _text(e.get('id'), 100),
                          "reason": _text(e.get('reason'), 1000), "source_id": _text(e.get('source_id'), 100),
                          "quote": _text(e.get('quote'), 2400),
                          "scope_quote": _text(e.get('scope_quote'), 2400),
                          "chunk": e.get('chunk') if type(e.get('chunk')) is int else None,
                          "bound_to_benchmark": e.get('bound_to_benchmark') is True}
                         for e in labels.get('evidence', []) if isinstance(e, dict)]
                        if isinstance(labels.get('evidence'), list) else [],
        }
    assets = item.get("assets", {})
    assets = assets.get("result") if isinstance(assets, dict) else None
    if isinstance(assets, dict):
        result["assets"]["status"] = _code(assets.get("status"), "AVAILABLE")
        for asset in assets.get("assets", []) if isinstance(assets.get("assets", []), list) else []:
            if not isinstance(asset, dict):
                continue
            row = {key: _text(asset.get(key, "")) for key in (
                "kind", "availability_claim", "license_claim", "license_claim_status",
                "evidence_quote", "link_status", "checked_at", "open_status", "reproduction_status")}
            row.update(url=_url(asset.get("url")), verified_open=False, replicated=False)
            result["assets"]["items"].append(row)
    return result


def build_snapshot(jobs, now, days=DEFAULT_WINDOW_DAYS, min_benchmarks=3, service_status=None,
                   task_profile=None, reference_models=None, candidate_models=None,
                   benchmark_months=DEFAULT_BENCHMARK_MONTHS, _task_evidence=None, score_panel=None, score_registry=None,
                   automatic_scoring=None, auto_score_panels=False, schedule_scoring=True):
    """Build a detached, strict-JSON public view at the supplied UTC instant.

    Expired papers and releases disappear even while extraction is running.
    Pending and review papers stay visible, but only explicitly eligible,
    unambiguous observations reach the exploratory index. Enrichment never
    supplies scoring labels. Original-table I/O, when enabled, is delegated to
    the scoring worker; this projection only applies its detached registry.
    """
    now = _utc(now)
    if isinstance(days, bool) or not isinstance(days, (int, float)) or not math.isfinite(days) or days <= 0:
        raise ValueError("days must be positive")
    start = now - timedelta(days=days)
    benchmark_start, benchmark_end = benchmark_window(now, benchmark_months)
    window = {"start": _iso(start), "end": _iso(now), "days": days,
              "benchmark_months": benchmark_months,
              "benchmark_start": _iso(benchmark_start), "benchmark_end": _iso(benchmark_end),
              "paper": {"start": _iso(start), "end": _iso(now), "days": days,
                        "basis": "PAPER_FIRST_PUBLISHED", "interval": "[start,end)"},
              "benchmark": {"start": _iso(benchmark_start), "end": _iso(benchmark_end),
                            "months": benchmark_months, "basis": "BENCHMARK_FIRST_RELEASE",
                            "unit": "calendar_months", "interval": "[start,end)"}}
    if not isinstance(jobs, list):
        raise ValueError("jobs must be a list")
    jobs = deepcopy(jobs)
    catalog, pending_observations, summaries, issues, annotation_sources = [], [], [], [], []
    omitted = Counter()
    for job in jobs:
        if not isinstance(job, dict) or not isinstance(job.get("paper"), dict):
            omitted["invalid_job"] += 1
            continue
        paper = job["paper"]
        paper_id = paper.get("paper_id") or paper.get("id")
        if not isinstance(paper_id, str) or not paper_id:
            omitted["invalid_paper_id"] += 1
            continue
        publication = paper.get("publication_date")
        paper_window = _window_state(publication, start, now)
        if paper_window == "OUTSIDE":
            omitted["paper_outside_window"] += 1
            continue
        status = _code(job.get("status"))
        gate = "REVIEW_DATE_BOUNDARY" if paper_window == "BOUNDARY" else "REVIEW_PUBLICATION_DATE" if paper_window == "UNKNOWN" else ""
        summary = {"paper_id": _text(paper_id), "title": _text(paper.get("title")),
                   "arxiv_id": _text(paper.get("arxiv_id")), "publication_date": _text(publication),
                   "url": _url(paper.get("url")), "status": status,
                   "window_status": gate or "CURRENT", "reason": _reason(gate or status)}
        if job.get('processing_status') == 'RUNNING':
            summary['processing_status'] = 'RUNNING'
        from .failures import safe_failure_details
        failure = safe_failure_details(job.get("failure_details"))
        if failure:
            summary["failure_details"] = failure
        if not gate and job.get("last_error") == "EVIDENCE_UNRESOLVED":
            summary["reason"] = ("证据不足，已停止自动补证；保留原因，等待新增证据或定向修复"
                                 if job.get('retry_at') is None else "证据不足，已安排限次复核")
            summary['automatic_retry'] = job.get('retry_at') is not None
            from .evidence_exclusion import settled_exclusion
            if settled_exclusion(job):
                summary.update(reason='最终证据不足且没有可发布成绩，按未达收录条件排除；停止自动补跑',
                               exclusion_code='INSUFFICIENT_EVIDENCE_NO_SCORES',automatic_retry=False)
        if not gate and status == 'COMPLETE' and job.get('last_error') == 'PARTIAL_RESULTS':
            summary['automatic_retry'] = job.get('retry_at') is not None
            summary['reason'] = ('已有合规成绩，未完成表等待限次技术修复' if summary['automatic_retry']
                                 else '已有合规成绩，其余未核实表已记录原因；自动补跑已停止')
        def resource_summary():
            if gate:
                return
            prefix = '已有合规成绩；' if status == 'COMPLETE' else ''
            if (job.get('last_error') == 'RESOURCE_RETRIES_EXHAUSTED'
                    or failure and failure.get('termination') == 'RESOURCE_LIMIT'):
                summary.update(reason=prefix + '基础设施恢复次数已耗尽；保留检查点，停止自动尝试', automatic_retry=False)
            elif service_status and service_status.get('extraction_paused') is True:
                summary['automatic_retry'] = False
                if failure and failure['kind'] in {'LLM_QUOTA', 'LLM_AUTH', 'LLM_TRANSIENT'}:
                    summary['reason'] = prefix + '模型服务已暂停；修复接口后明确恢复，不自动调用'
        resource_summary()
        imported = job.get('_imported_publication')
        if isinstance(imported, dict):
            summary.update(origin='IMPORTED_PUBLICATION',
                           captured_status=_code(imported.get('captured_status')),
                           snapshot_as_of=_text(imported.get('generated_at')), automatic_retry=False)
            if status == 'ARCHIVED':
                summary['reason'] = '历史快照未含原始任务队列；保留当时状态，不自动重跑'
        summaries.append(summary)
        result = job.get("result")
        if result is None:
            continue
        if not isinstance(result, dict) or not isinstance(result.get("catalog", []), list) or not isinstance(result.get("observations", []), list):
            summary.update(window_status="REVIEW_RESULT_INVALID", reason=_reason("REVIEW_RESULT_INVALID"))
            issues.append({"code": "REVIEW_RESULT_INVALID", "paper_id": paper_id})
            continue
        receipts = result.get('table_outcomes')
        resolution = result.get('resolution')
        if job.get('status') == 'EXCLUDED' and isinstance(resolution, dict):
            reason = {'NO_APPLICABLE_MODEL_SCORES': '全部成绩行已确认不符合模型收录要求；benchmark目录保留，停止自动补跑',
                      'SOURCE_SCOPE_EXCLUDED': '表格均已确认不含目标benchmark成绩，停止自动补跑'}.get(resolution.get('reason_code'))
            if reason:
                summary.update(exclusion_code=resolution['reason_code'], reason=reason)
        if isinstance(receipts, list):
            summary['table_outcome_counts'] = dict(Counter(item['status'] for item in receipts
                if isinstance(item, dict) and isinstance(item.get('status'), str)
                and item['status'] in {'ACCEPTED', 'EXCLUDED', 'FAILED'}))
        source_gate = (result.get("source_verified") is False
                       or bool(blocking_source_issues(result.get("source_issues", []))))
        if source_gate:
            summary.update(window_status="REVIEW_SOURCE", reason="来源完整性尚未通过核验，成绩暂不纳入")
        completion = result.get("completion")
        if isinstance(completion, dict):
            summary["extraction_complete"] = completion.get("extraction_complete") is True
            for key in ("accepted_observations", "unresolved_observations"):
                value = completion.get(key)
                if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                    summary[key] = value
            pending = completion.get("pending_table_ids", [])
            if isinstance(pending, list):
                summary["pending_tables"] = len(pending)
            for key in ('total_tables', 'processed_tables', 'selected_tables'):
                value = completion.get(key)
                if type(value) is int and value >= 0:
                    summary[key] = value
            if result.get('live_progress') is True:
                summary['reason'] = '正在提取；已通过核验的基础模型成绩持续更新'
                summary['live_progress'] = True
            if status == "COMPLETE" and summary["extraction_complete"] is False and result.get('live_progress') is not True:
                summary['automatic_retry'] = job.get('retry_at') is not None
                summary["reason"] = ('已有通过核验的基础模型成绩；其余表格等待限次技术修复'
                                     if summary['automatic_retry'] else
                                     '已有通过核验的基础模型成绩；其余未核实表已记录原因，自动补跑已停止')
        if not failure:
            failure = safe_failure_details(result.get("failure_details"))
            if failure:
                summary["failure_details"] = failure
        resource_summary()
        gaps = result.get("qualification_gaps", [])
        if isinstance(gaps, list) and isinstance(result.get("extraction_gaps", []), list):
            gaps = [*gaps, *result.get("extraction_gaps", [])]
        if isinstance(gaps, list):
            summary["evidence_gaps"] = [{"code": _code(item.get("code")), "stage": _code(item.get("stage"))}
                                        for item in gaps if isinstance(item, dict) and _code(item.get("code")) != "UNKNOWN"]
        enrichment = result.get("enrichment", {})
        enrichment_items = enrichment.get("items", []) if isinstance(enrichment, dict) else []
        enrichments = {(e.get("paper_id"), e.get("benchmark_id")): e for e in enrichment_items
                       if isinstance(e, dict) and isinstance(e.get("paper_id"), str) and isinstance(e.get("benchmark_id"), str)} if isinstance(enrichment_items, list) else {}
        for source in result.get("catalog", []):
            if not isinstance(source, dict) or source.get("paper_id", paper_id) != paper_id:
                continue
            benchmark_id = source.get("benchmark_id")
            if not isinstance(benchmark_id, str) or not benchmark_id:
                continue
            release_window = _window_state(source.get("release_date"), benchmark_start, benchmark_end)
            from .known_benchmark_dates import public_known_old
            if public_known_old(source, benchmark_start):
                release_window = 'OUTSIDE'
            if release_window == "OUTSIDE":
                omitted["benchmark_outside_window"] += 1
                continue
            entry = {key: _text(source.get(key, "")) for key in _CATALOG_TEXT}
            entry.update(paper_id=paper_id, paper_title=_text(paper.get("title")),
                         paper_first_published=_text(publication), source_url=_url(paper.get("url")),
                         arxiv_id=_text(paper.get("arxiv_id")), status=_code(source.get("status", status)),
                         benchmark_aliases=[_text(v) for v in source.get("benchmark_aliases", []) if isinstance(v, str)]
                         if isinstance(source.get("benchmark_aliases", []), list) else [])
            eligibility = source.get("eligibility")
            entry["eligibility"] = eligibility if isinstance(eligibility, str) and eligibility == _code(eligibility) else "NOT_ASSESSED"
            entry['tests_llms'] = source.get('tests_llms') is True
            entry['identity_conflict'] = source.get('identity_conflict') is True
            if isinstance(source.get('identity_resolution'), dict):
                proof = source['identity_resolution']
                entry['identity_resolution'] = {'relation':_code(proof.get('relation')),
                                               'evidence_quote':_text(proof.get('evidence_quote'),1800)}
            if entry['benchmark_name'] != source.get('benchmark_name', ''):
                # Redaction must not turn distinct raw primary names into one
                # source-confirmed cross-paper aggregation identity.
                entry['identity_conflict'] = True
            entry["reason"] = _reason(entry["eligibility"])
            if source.get('admission_basis') == 'SOURCE_NEW_RELEASE_CLAIM':
                entry['history_verified'] = source.get('history_verified') is True
                entry['date_proxy_assumed'] = source.get('date_proxy_assumed') is True
                entry['first_disclosure_assumed'] = source.get('first_disclosure_assumed') is True
                entry['reason'] = '按原文新发布声明收录；' + ('已有更早发布检索' if entry['history_verified'] else '更早发布检索未核实')
            elif source.get('admission_basis') == 'SOURCE_BENCHMARK_RELEASE_DATE':
                entry['history_verified'] = source.get('history_verified') is True
                entry['date_proxy_assumed'] = False
                entry['first_disclosure_assumed'] = False
                entry['reason'] = 'benchmark首次发布日期已由原文核验；论文与benchmark窗口独立计算'
            date_gate = gate or ("REVIEW_SOURCE" if source_gate else "") or ("REVIEW_DATE_BOUNDARY" if release_window == "BOUNDARY" else "REVIEW_RELEASE_DATE" if release_window == "UNKNOWN" else "")
            if date_gate:
                entry.update(eligibility=date_gate, reason=_reason(date_gate))
            entry["enrichment"] = _enrichment(enrichments.get((paper_id, benchmark_id)))
            catalog.append(entry)
        needs_model_recheck = False
        needs_value_recheck = False
        for row in result.get("observations", []):
            if isinstance(row, dict) and row.get("paper_id") == paper_id:
                from .observation_values import has_numeric_result
                if source_gate:
                    omitted["source_not_verified"] += 1
                elif row.get("model_kind") != "BASE" or row.get("base_model_verified") is not True:
                    omitted["non_base_or_unverified_model"] += 1
                    needs_model_recheck = True
                elif not has_numeric_result(row):
                    omitted["missing_or_invalid_score"] += 1
                    needs_value_recheck = True
                else:
                    pending_observations.append({**row, **({'extraction_in_progress': True}
                        if result.get('live_progress') is True else {})})
        if needs_model_recheck:
            issues.append({"code": "BASE_MODEL_RECHECK_REQUIRED", "paper_id": paper_id})
        if needs_value_recheck:
            issues.append({"code": "NUMERIC_SCORE_RECHECK_REQUIRED", "paper_id": paper_id})
        annotation_sources.append((paper_id, result.get("capability_annotations")))

    # Retries may repeat the same identity, but conflicting snapshots must not
    # be picked by insertion order. Independent papers remain independent.
    identities = defaultdict(list)
    for entry in catalog:
        identities[(entry["paper_id"], entry["benchmark_id"])].append(entry)
    catalog = []
    for key, entries in sorted(identities.items()):
        entry = entries[0]
        if any(other != entry for other in entries[1:]):
            entry.update(eligibility="REVIEW_DUPLICATE_IDENTITY", reason=_reason("REVIEW_DUPLICATE_IDENTITY"))
            issues.append({"code": "REVIEW_DUPLICATE_IDENTITY", "paper_id": key[0], "benchmark_id": key[1]})
        catalog.append(entry)
    from .benchmark_identity import conflicting_benchmark_identities, source_benchmark_identity
    conflicts = conflicting_benchmark_identities(catalog)
    for entry in catalog:
        if (entry["paper_id"], entry["benchmark_id"]) in conflicts:
            entry.update(eligibility="REVIEW_DUPLICATE_IDENTITY", reason=_reason("REVIEW_DUPLICATE_IDENTITY"))
    eligible = {(e["paper_id"], e["benchmark_id"]) for e in catalog if e["eligibility"] == "ELIGIBLE"}
    aggregation_identities = {(e['paper_id'], e['benchmark_id']): source_benchmark_identity(e)
                              for e in catalog if e['eligibility'] == 'ELIGIBLE'}
    for entry in catalog:
        canonical = aggregation_identities.get((entry['paper_id'], entry['benchmark_id']))
        if canonical:
            entry['benchmark_identity'] = canonical
    by_id, bad_ids, bad_benchmarks = {}, set(), set()
    for row in pending_observations:
        identity = (row.get("paper_id"), row.get("benchmark_id"))
        identifier = row.get("observation_id")
        if identity not in eligible or not isinstance(identifier, str) or not identifier:
            continue
        # Never trust a persisted aggregation key: derive it from current,
        # admitted source-release proof, preserving original source/group IDs.
        row = {key: value for key, value in row.items() if key != 'benchmark_identity'}
        if canonical := aggregation_identities.get(identity):
            row['benchmark_identity'] = canonical
        if identifier in by_id and by_id[identifier] != row:
            bad_ids.add(identifier)
            previous = by_id[identifier]
            bad_benchmarks.update((identity, (previous.get("paper_id"), previous.get("benchmark_id"))))
        else:
            by_id[identifier] = row
    for identifier in sorted(bad_ids):
        issues.append({"code": "REVIEW_OBSERVATION_CONFLICT", "observation_id": identifier})
    for entry in catalog:
        if (entry["paper_id"], entry["benchmark_id"]) in bad_benchmarks:
            entry.update(eligibility="REVIEW_OBSERVATION_CONFLICT", reason=_reason("REVIEW_OBSERVATION_CONFLICT"))
    observations = []
    for identifier, source in sorted(by_id.items()):
        if identifier in bad_ids or (source.get("paper_id"), source.get("benchmark_id")) in bad_benchmarks:
            continue
        # Score raw semantic strings first: public redaction must never merge
        # distinct model identities or turn malformed values into valid data.
        observations.append(source)
    # Show validated running cells immediately. Rankings use completed bundles
    # so partially collected metric groups cannot bias a model's current rank.
    index_observations = [row for row in observations if not row.get('extraction_in_progress')]
    scale_audit = []
    automatic_audit = None
    if automatic_scoring is not None and score_registry is None:
        index_observations, automatic_audit = automatic_scoring.calibrate(index_observations, schedule=schedule_scoring)
    if score_registry is not None:
        from .scoring_preparation import apply_registry
        index_observations, scale_audit = apply_registry(index_observations, score_registry)
    from .public_model_registry import project_model_names
    from .publication_quality import remap_annotations
    index_observations, _ = project_model_names(index_observations)
    # Group identities include paper_id. Rehashing every published row for
    # every paper is quadratic, and cannot contribute a valid cross-paper label.
    annotation_rows = defaultdict(list)
    for row in index_observations:
        annotation_rows[row.get('paper_id')].append(row)
    annotation_sources = [(paper, remap_annotations(envelope, annotation_rows[paper]))
                          for paper, envelope in annotation_sources]
    # Scoring consumes the source-audited catalogue task labels. Prepare them
    # before fitting, rather than attaching display-only labels afterwards.
    from .benchmark_directory import prepare_catalog
    catalog = prepare_catalog(catalog)
    index = build_index(index_observations, min_benchmarks=min_benchmarks, score_panel=score_panel)
    index['scale_registry_audit'] = scale_audit
    if auto_score_panels and score_panel is None:
        from .global_scoring import apply_global_scores
        apply_global_scores(index, min_benchmarks=min_benchmarks, benchmark_catalog=catalog, as_of=now)
    if automatic_audit is not None:
        index['scoring_preparation'] = automatic_audit
    approved_scales = {g['group_id']: g['score_scale'] for g in index['groups'] if g.get('score_scale')}
    # Reuse exactly the approved scales in task scoring; never infer them from
    # metric names or the currently displayed opponents.
    if approved_scales:
        calibrated_observations = []
        for row in index_observations:
            try:
                scale = approved_scales.get(group_id_for(row))
            except (KeyError, TypeError, ValueError):
                scale = None
            calibrated_observations.append(dict(row, score_scale=deepcopy(scale)) if scale else row)
        index_observations = calibrated_observations
    # Benchmark detail charts can show provisional groups without publishing
    # provisional models into the overall or task ranking.
    progress_groups = build_index([row for row in observations if row.get('extraction_in_progress')],
                                  min_benchmarks=min_benchmarks)['groups']
    for group in progress_groups:
        group['extraction_in_progress'] = True
    index.update(kind="GLOBAL_BENCHMARK_COMPOSITE" if index['method'].get('global_composite') else "COMMON_REFERENCE_RELATIVE_INDEX" if index['method'].get('score_unit')=='z_score' else "SOURCE_FIXED_SCALE_INDEX", score_origin="PAPER_REPORTED",
                 task_index={"available": False, "status": "PROFILE_REQUIRED",
                             "note": "任务评分需要确认任务能力与权重，并核验匹配指标的固定量程；原始成绩和证据覆盖可先查看。"})
    task_index = dict(index["task_index"], models=[])
    # Expose the source-audited group labels, rather than using catalogue tags
    # as evidence for task scores. Only groups with current, completed cells
    # are included; expired and in-progress evidence cannot enter this map.
    current_groups = {}
    for row in index_observations:
        try:
            current_groups[group_id_for(row)] = row
        except (ValueError, TypeError):
            # Legacy partial scores may lack an explicit setting. Keep their
            # source cells visible, but do not invent task-group metadata or
            # crash publication while a stopped service is being recovered.
            issues.append({'code': 'REVIEW_COMPARISON_GROUP', 'paper_id': _text(row.get('paper_id'))})
    public_annotations, seen_annotations = [], set()
    for paper_id, envelope in annotation_sources:
        if (not isinstance(envelope, dict) or envelope.get("schema_version") != ANNOTATION_VERSION
                or envelope.get("taxonomy_version") not in SUPPORTED_TAXONOMY_VERSIONS
                or not isinstance(envelope.get("items"), list)):
            continue
        for item in envelope["items"]:
            if not isinstance(item, dict) or not isinstance(item.get("group_id"), str):
                continue
            source = current_groups.get(item.get("group_id"))
            if source is None or source.get("paper_id") != paper_id:
                continue
            try:
                key = json.dumps(item, sort_keys=True, ensure_ascii=False, allow_nan=False)
            except (ValueError, TypeError):
                continue
            if key in seen_annotations:
                continue
            seen_annotations.add(key)
            public_annotations.append(_public({**item, **{k: source.get(k) for k in
                ("paper_id", "benchmark_id", "table_id", "metric", "row_key", "model_setting")}}))
    capability_annotations = {"schema_version": ANNOTATION_VERSION,
        "taxonomy_version": TAXONOMY_VERSION, "items": public_annotations,
        "total_groups": len(current_groups),
        "unannotated_groups": len(set(current_groups) - {x["group_id"] for x in public_annotations})}
    from .capability_atlas import build_atlas
    capability_atlas = build_atlas(catalog, capability_annotations)
    capability_annotations.update({key: capability_atlas['coverage'][key]
                                   for key in ('supported_groups', 'review_groups')})
    if _task_evidence is not None:
        from .catalog_task_scoring import prepare_inputs
        task_source_index, task_source_catalog = prepare_inputs(index, catalog, index_observations)
        _task_evidence.update(observations=deepcopy(index_observations),
            annotation_sources=deepcopy(annotation_sources),
            unannotated_groups=capability_annotations['unannotated_groups'],
            catalog_task={'index':task_source_index,'benchmarks':task_source_catalog})
    from .task_projection import project_task
    task_index = project_task(index_observations, annotation_sources,
        capability_annotations['unannotated_groups'], task_profile, reference_models,
        candidate_models, min_benchmarks)
    index["task_index"] = {key: task_index[key] for key in ("available", "status", "note")}
    from .public_model_registry import project_model_names
    normalized_observations, model_registry = project_model_names(observations)
    for entry in model_registry['models']:
        entry['canonical_name'] = _text(entry['canonical_name'])
        for field in ('source_names', 'comparison_names'):
            entry[field] = [_text(value) for value in entry[field]]
    public_observations = []
    for original, source in zip(observations, normalized_observations):
        row = {key: _text(source[key]) for key in _OBSERVATION_TEXT if key in source}
        row.update({key: _public(source[key]) for key in _NUMERIC_FIELDS if key in source})
        row.update({key: source.get(key) is True for key in ("model_verified", "comparable", "base_model_verified", "base_model_assumed")})
        row['source_model_canonical'] = _text(source.get('source_model_canonical', original.get('model_canonical', '')))
        row['extraction_in_progress'] = source.get('extraction_in_progress') is True
        public_observations.append(row)
    service = service_status if isinstance(service_status, dict) else {}
    service_view = {"state": _code(service.get("state")), "stale": service.get("stale", True) is not False,
                    "discovery_status": _code(service.get("discovery_status")),
                    "discovery_complete": service.get("discovery_complete") is True,
                    "discovery_partial": service.get("discovery_partial") is True}
    if isinstance(service.get('code_version'), str):
        service_view['code_version'] = _text(service['code_version'], 120)
    if type(service.get('service_pid')) is int and service['service_pid'] > 0:
        service_view['service_pid'] = service['service_pid']
    for key in ("started_at", "last_poll_at", "last_success_at", "next_poll_at",
                "last_discovery_at", "last_full_discovery_at", "discovery_retry_at"):
        try:
            service_view[key] = _iso(_utc(service[key]))
        except (KeyError, ValueError, TypeError):
            service_view[key] = None
    for key in ("poll_interval_seconds", "worker_count", "screen_worker_count", "queue_depth",
                "active_workers", "active_screen_workers", "active_extraction_workers",
                "active_download_workers", "active_parse_workers", "active_analysis_workers", "active_background_workers",
                "download_worker_count", "parse_worker_count", "background_worker_count", "stage_buffer"):
        value = service.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0:
            service_view[key] = value
    if isinstance(service.get("phase_counts"), dict):
        service_view["phase_counts"] = {
            phase: count for phase, count in service["phase_counts"].items()
            if phase in {"SCREEN", "EXTRACT", "LEGACY", "DOWNLOAD", "PARSE", "ANALYZE"}
            and isinstance(count, int) and not isinstance(count, bool) and count >= 0}
    for key in ("service_deferred_jobs", "partial_result_jobs", "evidence_closed_jobs", "evidence_excluded_jobs", "resource_closed_jobs", "shared_recovery_rounds"):
        value = service.get(key)
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            service_view[key] = value
    service_view['extraction_paused'] = service.get('extraction_paused') is True
    for key in ('screen_paused', 'analysis_paused', 'processing_paused', 'processing_pause_requires_resume'):
        if type(service.get(key)) is bool:
            service_view[key] = service[key]
    if isinstance(service.get('paused_stages'), list):
        service_view['paused_stages'] = [phase for phase in service['paused_stages']
            if phase in {'SCREEN', 'DOWNLOAD', 'PARSE', 'ANALYZE', 'BACKGROUND'}]
    if isinstance(service.get('model_pauses'), dict):
        from .model_pauses import ModelPauses
        service_view['model_pauses'] = _public(ModelPauses(service['model_pauses']).snapshot())
    service_view['extraction_error_code'] = _code(service['extraction_error_code']) if service.get('extraction_error_code') else None
    if 'processing_pause_reason' in service:
        service_view['processing_pause_reason'] = (_code(service['processing_pause_reason'])
            if service.get('processing_pause_reason') else None)
    if 'processing_retry_at' in service:
        try:
            service_view['processing_retry_at'] = _iso(_utc(service['processing_retry_at']))
        except (ValueError, TypeError):
            service_view['processing_retry_at'] = None
    service_view['stage_pipeline'] = service.get('stage_pipeline') is True
    if isinstance(service.get('background_jobs'), dict):
        service_view['background_jobs'] = _public(service['background_jobs'])
    for key in ("failure_counts", "failure_stages"):
        value = service.get(key)
        if isinstance(value, dict):
            service_view[key] = {_code(code): count for code, count in value.items()
                                 if isinstance(count, int) and not isinstance(count, bool) and count >= 0
                                 and _code(code) != "UNKNOWN"}
    try:
        service_view["extraction_retry_at"] = _iso(_utc(service["extraction_retry_at"]))
    except (KeyError, ValueError, TypeError):
        service_view["extraction_retry_at"] = None
    if isinstance(service.get("running"), bool):
        service_view["running"] = service["running"]
    if service.get("discovery_scan_mode") in {"FULL", "INCREMENTAL"}:
        service_view["discovery_scan_mode"] = service["discovery_scan_mode"]
    error_code = service.get("last_error_code") or service.get("error_code")
    if error_code:
        service_view["last_error_code"] = _code(error_code, "SERVICE_ERROR")
        service_view["reason"] = "服务最近一次操作失败，请检查本地日志"
        service_view["stale"] = True
    status = {**service_view, "paper_days": days, "benchmark_months": benchmark_months,
        "paper_window": window["paper"], "benchmark_window": window["benchmark"],
        "counts": {"papers": len(summaries), "benchmarks": len(catalog),
        "eligible_benchmarks": len({e.get('benchmark_identity', (e['paper_id'], e['benchmark_id']))
                                    for e in catalog if e['eligibility'] == 'ELIGIBLE'}),
        "eligible_benchmark_evaluations": sum(e['eligibility'] == 'ELIGIBLE' for e in catalog),
        "observations": len(public_observations), "index_models": len(index["models"]),
        "papers_with_scores": len({o['paper_id'] for o in public_observations}),
        "papers_with_eligible_benchmarks": len({e['paper_id'] for e in catalog if e['eligibility'] == 'ELIGIBLE'}),
        "extraction_finished_papers": sum(s.get('extraction_complete') is True for s in summaries),
        "in_progress_observations": sum(o['extraction_in_progress'] for o in public_observations)},
        "job_statuses": dict(Counter(s["status"] for s in summaries)), "jobs": summaries,
        "issues": issues, "omitted": dict(omitted),
        "note": f"论文首次公开限定近{days:g}天；benchmark 首次发布限定近{benchmark_months}个日历月，两个窗口独立计算。来源成绩未经本服务复现。"}
    from .public_statistics import public_statistics, STATISTICS_METHOD
    status['counts'].update(public_statistics(catalog, public_observations, index))
    status['statistics_method'] = STATISTICS_METHOD
    if isinstance(service.get('imported_publication'), dict):
        status['imported_publication'] = _public(service['imported_publication'])
    from .benchmark_progress import attach_progress
    attach_progress(catalog, public_observations, capability_annotations, summaries)
    snapshot = _public({"generated_at": _iso(now), "window": window,
        "status": status, "benchmarks": catalog, "observations": public_observations,
        "score_groups": [*index['groups'], *progress_groups],
        "index": index, "task_index": task_index, "model_registry": model_registry,
        "capability_annotations": capability_annotations, "capability_atlas": capability_atlas})
    snapshot["snapshot_id"] = sha256(json.dumps(snapshot, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()).hexdigest()[:24]
    return snapshot


def benchmark_detail(snapshot, paper_id, benchmark_id):
    """Expose one current-window benchmark and its own reported scores."""
    match = next((row for row in snapshot["benchmarks"]
                  if row["paper_id"] == paper_id and row["benchmark_id"] == benchmark_id), None)
    if match is None:
        return None
    identity = (paper_id, benchmark_id)
    task = snapshot.get("task_index", {})
    panel = [row for row in task.get("panel", [])
             if (row.get("paper_id"), row.get("benchmark_id")) == identity]
    panel_groups = {row.get("group_id") for row in panel}
    return {"snapshot_id": snapshot["snapshot_id"], "generated_at": snapshot["generated_at"],
            "window": snapshot["window"], "benchmark": match,
            "capability_annotations": [row for row in snapshot.get('capability_annotations', {}).get('items', [])
                if (row.get('paper_id'), row.get('benchmark_id')) == identity],
            "observations": [row for row in snapshot["observations"]
                             if (row.get("paper_id"), row.get("benchmark_id")) == identity],
            "metric_groups": [row for row in snapshot.get('score_groups', snapshot["index"].get("groups", []))
                              if (row.get("paper_id"), row.get("benchmark_id")) == identity],
            "task_matches": panel,
            "task_comparisons": [row for row in task.get("comparisons", [])
                                 if row.get("benchmark_id") == benchmark_id and row.get("group_id") in panel_groups]}


_BENCHMARK_PAGE = r'''<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Benchmark 详情 · 模型评测</title><style>
:root{color-scheme:light}*{box-sizing:border-box}body{font:15px/1.55 system-ui,sans-serif;margin:0;background:#f5f7fb;color:#18243a}
main{max-width:1120px;margin:auto;padding:1.5rem 1rem 4rem}a{color:#1554ad}button,select{font:inherit}button{cursor:pointer;border:1px solid #cad5e6;border-radius:8px;background:white;padding:.5rem .8rem}
h1{font-size:clamp(1.65rem,3vw,2.5rem);line-height:1.2;margin:.45rem 0}h2{font-size:1.2rem;margin:0 0 .75rem}.muted{color:#5b677c}.top{display:flex;justify-content:space-between;gap:1rem;align-items:center}
.card{background:#fff;border:1px solid #dce4f0;border-radius:14px;padding:1.15rem;margin-top:1rem;box-shadow:0 2px 12px #162a4a08}.hero{padding:1.6rem}
.badge{display:inline-flex;align-items:center;border-radius:999px;background:#e7f3eb;color:#126441;padding:.22rem .65rem;font-weight:650}.badge.review{background:#fff0df;color:#8b4911}
.meta{display:flex;flex-wrap:wrap;gap:.6rem 1.5rem}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.75rem;margin-top:1rem}.stat{background:#f1f5fb;border-radius:10px;padding:.75rem}.stat strong{display:block;font-size:1.5rem}
.chips{display:flex;flex-wrap:wrap;gap:.4rem}.chip{background:#eef2fa;border-radius:999px;padding:.25rem .65rem}.grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{padding:.65rem;border-bottom:1px solid #e6ebf2;text-align:left;vertical-align:top}th{white-space:nowrap}
.group-controls{display:flex;align-items:center;gap:.7rem;flex-wrap:wrap}.group-controls select{min-width:260px;max-width:100%;padding:.5rem;border:1px solid #cad5e6;border-radius:8px;background:white}
.bar-row{display:grid;grid-template-columns:minmax(130px,1.4fr) minmax(100px,3fr) auto;align-items:center;gap:.7rem;padding:.45rem 0;border-bottom:1px solid #edf0f5}.bar-track{height:14px;background:#ecf1f8;border-radius:999px;overflow:hidden}.bar-fill{height:100%;background:#3478d4;border-radius:999px}.bar-value{font-variant-numeric:tabular-nums;white-space:nowrap}
@media(max-width:700px){.stats{grid-template-columns:repeat(2,1fr)}.grid{grid-template-columns:1fr}.bar-row{grid-template-columns:1fr 2fr auto}}
</style><main>
<div class="top"><a href="/">← 返回模型评测</a><button id="refresh" type="button">刷新</button></div>
<section class="card hero"><span id="status-badge" class="badge">读取中</span><h1 id="title">正在读取 Benchmark…</h1><p id="summary" class="muted"></p><div id="meta" class="meta"></div><div id="stats" class="stats"></div></section>
<div class="grid"><section class="card"><h2>能力与任务标签</h2><div id="tags"></div></section><section class="card"><h2>论文与公开资源</h2><div id="resources"></div></section></div>
<section class="card"><h2>模型成绩对比</h2><p class="muted">仅比较同一来源表、同一指标、同一任务行与实验设置。条形长度是该组论文成绩的相对对手得分，不是跨 benchmark 总分。</p><div class="group-controls"><label for="metric-group">选择可比指标</label><select id="metric-group"></select></div><p id="group-status" class="muted"></p><div id="chart"></div></section>
<section class="card scroll"><h2>论文报告的全部来源成绩</h2><div id="observations"></div></section>
<section class="card scroll"><h2>当前任务匹配证据</h2><p class="muted">只有配置了任务画像与固定参考模型，才会显示公共任务面板；用户专属榜单可通过任务评分 API 单独计算。</p><div id="task-matches"></div></section>
<p id="window" class="muted"></p></main><script>
'use strict';
const el=(tag,value)=>{const node=document.createElement(tag);if(value!==undefined)node.textContent=String(value);return node;};
const show=value=>value===null||value===undefined||value===''?'—':Array.isArray(value)?value.join('、'):String(value);
function safeLink(url,label){try{const u=new URL(url);if(['http:','https:'].includes(u.protocol)&&!u.username&&!u.password){const a=el('a',label||url);a.href=u.href;a.target='_blank';a.rel='noopener noreferrer';return a;}}catch{}return el('span',label||'—');}
function drawTable(target,rows,columns){const root=document.getElementById(target);root.replaceChildren();if(!rows.length){root.append(el('p','当前没有可展示记录。'));return;}const t=el('table'),h=el('tr');for(const [title] of columns)h.append(el('th',title));t.append(h);for(const row of rows){const tr=el('tr');for(const [,key] of columns)tr.append(el('td',show(row[key])));t.append(tr);}root.append(t);}
function chips(target,title,values){const root=document.getElementById(target),line=el('div'),label=el('strong',title+'：');line.append(label);const items=Array.isArray(values)?values:[];if(!items.length)line.append(el('span','待核实'));else{const box=el('span');box.className='chips';for(const value of items){const chip=el('span',value);chip.className='chip';box.append(chip);}line.append(box);}root.append(line);}
let detail=null,loading=false,chosenGroup='';
function chart(){const root=document.getElementById('chart'),note=document.getElementById('group-status'),select=document.getElementById('metric-group');root.replaceChildren();const group=(detail.metric_groups||[]).find(g=>g.group_id===select.value);if(!group){note.textContent='尚无可比的模型成绩；来源观测和审核状态仍可查看。';return;}if((group.blocked_reasons||[]).length){note.textContent='此组不能排名：'+show(group.blocked_reasons);return;}const scores=[...(group.scores||[])].sort((a,b)=>b.score-a.score||a.model_canonical.localeCompare(b.model_canonical));note.textContent='来源表 '+show(group.table_id)+' · 指标 '+show(group.metric)+' · 方向 '+(group.direction==='lower'?'越低越好':'越高越好')+' · 模型 '+scores.length+' 个';for(const row of scores){const line=el('div');line.className='bar-row';const name=el('strong',row.model_canonical),track=el('div'),fill=el('div'),value=el('span',show(row.value_numeric)+' · 相对 '+show(row.score));track.className='bar-track';fill.className='bar-fill';fill.style.width=Math.max(0,Math.min(100,Number(row.score)||0))+'%';value.className='bar-value';track.append(fill);line.append(name,track,value);root.append(line);}}
function render(d){detail=d;const b=d.benchmark,e=b.enrichment||{},labels=e.labels||{},assets=e.assets||{},badge=document.getElementById('status-badge');document.title=b.benchmark_name+' · 新 Benchmark';document.getElementById('title').textContent=b.benchmark_name;badge.textContent=b.eligibility==='ELIGIBLE'?'已核实纳入':'待复核 · '+show(b.eligibility);badge.className='badge'+(b.eligibility==='ELIGIBLE'?'':' review');document.getElementById('summary').textContent=show(b.reason);const meta=document.getElementById('meta');meta.replaceChildren(el('span','Benchmark 首次发布：'+show(b.release_date)),el('span','论文首次公开：'+show(b.paper_first_published)),el('span','核验依据：'+show(b.date_basis)));const models=new Set(d.observations.map(r=>r.model_canonical).filter(Boolean));const stats=document.getElementById('stats');stats.replaceChildren();for(const [name,value] of [['来源成绩',d.observations.length],['涉及模型',models.size],['可比指标组',(d.metric_groups||[]).filter(g=>!(g.blocked_reasons||[]).length).length],['任务匹配组',d.task_matches.length]]){const box=el('div');box.className='stat';box.append(el('strong',value),el('span',name));stats.append(box);}const tags=document.getElementById('tags');tags.replaceChildren();chips('tags','领域',labels.domains);chips('tags','任务',labels.tasks);chips('tags','能力',labels.capabilities);tags.append(el('p','标签状态：'+show(labels.status)));const resources=document.getElementById('resources');resources.replaceChildren();const paper=el('p');paper.append(safeLink(b.source_url,b.paper_title));resources.append(paper,el('p','首次发布日期证据：'+show(b.evidence_quote)));for(const item of assets.items||[]){const line=el('p');line.append(safeLink(item.url,item.kind||'资源'),el('span',' · '+show(item.link_status)+' · 许可 '+show(item.license_claim)));resources.append(line);}if(!(assets.items||[]).length)resources.append(el('p','尚无已确认公开资源'));const select=document.getElementById('metric-group');select.replaceChildren();for(const g of d.metric_groups||[]){const opt=el('option',show(g.metric)+' · '+show(g.row_key)+' · '+show(g.model_setting)+' · '+show(g.table_id)+(g.blocked_reasons.length?'（待复核）':''));opt.value=g.group_id;select.append(opt);}if(!(d.metric_groups||[]).some(g=>g.group_id===chosenGroup))chosenGroup=(d.metric_groups||[]).find(g=>!(g.blocked_reasons||[]).length)?.group_id||d.metric_groups[0]?.group_id||'';select.value=chosenGroup;chart();drawTable('observations',d.observations,[['模型','model_canonical'],['实验设置','model_setting'],['指标','metric'],['论文原值','value_raw'],['数值','value_numeric'],['表','table_id'],['行','row_key'],['观测 ID','observation_id']]);drawTable('task-matches',d.task_matches,[['能力','capability_id'],['任务匹配','match_kind'],['指标','metric'],['设置','model_setting'],['审核阻断','blocked_reasons'],['证据组','group_id']]);document.getElementById('window').textContent='论文近'+d.window.days+'天 ['+d.window.start+', '+d.window.end+') · Benchmark近'+d.window.benchmark_months+'个日历月 ['+d.window.benchmark_start+', '+d.window.benchmark_end+') · 每15秒检查一次 · 来源成绩未经本服务复现';}
async function refresh(){if(loading)return;loading=true;const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),10000);try{const q=new URLSearchParams(location.search),paper=q.get('paper_id'),benchmark=q.get('benchmark_id');if(!paper||!benchmark||q.size!==2)throw new Error('invalid_identity');const response=await fetch('/api/benchmark?'+new URLSearchParams({paper_id:paper,benchmark_id:benchmark}),{cache:'no-store',signal:controller.signal});if(!response.ok)throw new Error(response.status===404?'expired':'unavailable');render(await response.json());}catch(error){detail=null;document.getElementById('title').textContent=error.message==='expired'?'此 Benchmark 已离开当前窗口':'Benchmark 详情暂不可用';document.getElementById('summary').textContent=error.message==='expired'?'当前页面只显示当前窗口的新 Benchmark。':'请检查链接或稍后刷新。';for(const id of ['meta','stats','tags','resources','chart','observations','task-matches','window','group-status','metric-group'])document.getElementById(id).replaceChildren();}finally{clearTimeout(timeout);loading=false;}}
document.getElementById('metric-group').addEventListener('change',event=>{chosenGroup=event.target.value;chart();});document.getElementById('refresh').addEventListener('click',refresh);refresh();setInterval(refresh,15000);
</script></html>'''


from .web_theme import themed_pages

_DASHBOARD, _BENCHMARK_PAGE = themed_pages(_BENCHMARK_PAGE)
from .benchmark_page import PAGE as _BENCHMARK_PAGE
_BENCHMARK_PAGE = page_with_catalog_facets(_BENCHMARK_PAGE)


def _public_status_summary(value):
    """Keep queue diagnostics public without accepting arbitrary provider data."""
    if not isinstance(value, dict):
        raise ValueError("status provider must return an object")
    result = {}
    for key in ("snapshot_id", "code_version"):
        if isinstance(value.get(key), str):
            result[key] = _text(value[key], 120)
    for key in ("generated_at", "started_at", "last_poll_at", "last_success_at", "next_poll_at",
                "last_discovery_at", "last_full_discovery_at", "discovery_retry_at",
                "extraction_retry_at", "processing_retry_at", "counts_generated_at", "earliest_retry_at"):
        if key in value:
            try:
                result[key] = _iso(_utc(value[key]))
            except (ValueError, TypeError):
                result[key] = None
    for key in ("state", "discovery_status", "last_error_code", "extraction_error_code",
                "discovery_scan_mode", "counts_scope", "processing_pause_reason"):
        if key in value:
            result[key] = _code(value[key]) if value[key] is not None else None
    for key in ("running", "stale", "discovery_complete", "discovery_partial",
                "extraction_paused", "stage_pipeline", "screen_paused", "analysis_paused", "processing_paused",
                "processing_pause_requires_resume"):
        if isinstance(value.get(key), bool):
            result[key] = value[key]
    if isinstance(value.get('paused_stages'), list):
        result['paused_stages'] = [phase for phase in value['paused_stages']
            if phase in {'SCREEN', 'DOWNLOAD', 'PARSE', 'ANALYZE', 'BACKGROUND'}]
    if isinstance(value.get('model_pauses'), dict):
        from .model_pauses import ModelPauses
        result['model_pauses'] = _public(ModelPauses(value['model_pauses']).snapshot())
    for key in ("service_pid", "paper_days", "benchmark_months", "poll_interval_seconds",
                "worker_count", "screen_worker_count", "queue_depth", "active_workers",
                "active_screen_workers", "active_extraction_workers", "active_download_workers",
                "active_parse_workers", "active_analysis_workers", "active_background_workers",
                "download_worker_count", "parse_worker_count", "background_worker_count", "stage_buffer",
                "service_deferred_jobs", "partial_result_jobs", "evidence_closed_jobs", "evidence_excluded_jobs",
                "resource_closed_jobs", "shared_recovery_rounds"):
        number = value.get(key)
        if isinstance(number, (int, float)) and not isinstance(number, bool) and math.isfinite(number) and number >= 0:
            result[key] = number

    def counts(source):
        return {key: count for key, count in source.items()
                if isinstance(key, str) and not _PRIVATE_KEYS.search(key)
                and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", key)
                and isinstance(count, int) and not isinstance(count, bool) and count >= 0}

    for key in ("counts", "job_statuses", "processing_job_statuses", "phase_counts", "running_phase_counts",
                "due_phase_counts", "failure_counts", "failure_stages", "omitted"):
        if isinstance(value.get(key), dict):
            result[key] = counts(value[key])
        elif key == "counts" and key in value and value[key] is None:
            result[key] = None
    if isinstance(value.get("background_jobs"), dict):
        source = value["background_jobs"]
        result["background_jobs"] = counts({key: source[key] for key in
            ("pending", "running", "retry_wait", "closed_failed", "max_attempts") if key in source})
        if isinstance(source.get("active_counts"), dict):
            result["background_jobs"]["active_counts"] = counts(source["active_counts"])

    def window(source):
        if not isinstance(source, dict):
            return None
        view = {}
        for key in ("start", "end", "benchmark_start", "benchmark_end"):
            if key in source:
                try:
                    view[key] = _iso(_utc(source[key]))
                except (ValueError, TypeError):
                    view[key] = None
        for key in ("days", "months", "benchmark_months"):
            number = source.get(key)
            if isinstance(number, (int, float)) and not isinstance(number, bool) and math.isfinite(number) and number > 0:
                view[key] = number
        choices = {"basis": {"PAPER_FIRST_PUBLISHED", "BENCHMARK_FIRST_RELEASE"},
                   "unit": {"calendar_months"}, "interval": {"[start,end)"}}
        for key, options in choices.items():
            if isinstance(source.get(key), str) and source[key] in options:
                view[key] = source[key]
        for key in ("paper", "benchmark"):
            if isinstance(source.get(key), dict):
                view[key] = window(source[key])
        return view

    for key in ("window", "paper_window", "benchmark_window"):
        if isinstance(value.get(key), dict):
            result[key] = window(value[key])
    if isinstance(value.get('publication'), dict):
        result['publication'] = {key: n for key, n in value['publication'].items()
            if key in {'projection_seconds','encoding_seconds','total_seconds','full_payload_bytes',
                       'workspace_payload_bytes','full_gzip_bytes','workspace_gzip_bytes'}
            and isinstance(n, (int,float)) and not isinstance(n,bool) and math.isfinite(n) and n >= 0}
    if isinstance(value.get('scoring'), dict):
        result['scoring'] = {key: value['scoring'][key] for key in ('preparation','publication','panel_status')
                             if key in value['scoring']}
    return _public(result)


class RadarHTTPServer(ThreadingHTTPServer):
    """Allow short connection bursts without the five-connection default."""
    request_queue_size = 128
    daemon_threads = True


def make_server(host="127.0.0.1", port=8765, snapshot_provider=None, task_score_provider=None,
                task_profile_provider=None, *, status_provider=None, snapshot_bytes_provider=None,
                task_score_bytes_provider=None):
    """Return a read-only server with optional task scoring and queue diagnostics."""
    if not callable(snapshot_provider):
        raise ValueError("snapshot_provider must be callable")
    if status_provider is not None and not callable(status_provider):
        raise ValueError("status_provider must be callable")
    lock = threading.Lock()
    score_slots = threading.BoundedSemaphore(2)
    profile_slots = threading.BoundedSemaphore(1)
    measurement_cache={}

    from .interactive_jobs import InteractiveJobs, JobsFull
    def profile_job(payload):
        from .task_labels import validate_profile
        profile = validate_profile(task_profile_provider(payload['description']))
        if profile['description'] != payload['description']:
            raise ValueError('description changed')
        return {'profile': _public(profile)}
    def score_job(payload):
        if task_score_bytes_provider is not None:
            revision = json.loads(snapshot_bytes_provider('_task_revision', False)[0]) if snapshot_bytes_provider else None
            wire, _ = task_score_bytes_provider(payload['profile'], payload['reference_models'], payload.get('candidate_models'), False)
            return {'_revision': revision, '_result': json.loads(wire)}
        snapshot = task_score_provider(payload['profile'], payload['reference_models'], payload.get('candidate_models'))
        return _public({k: snapshot[k] for k in ('snapshot_id', 'generated_at', 'window', 'task_index')})
    def validate_job_result(kind, value):
        if kind == 'score' and '_result' in value:
            if snapshot_bytes_provider and value['_revision'] != json.loads(snapshot_bytes_provider('_task_revision', False)[0]):
                raise ValueError('evidence changed')
            return value['_result']
        return value
    jobs = InteractiveJobs({'profile': profile_job if task_profile_provider else None,
                            'score': score_job if task_score_provider else None}, validate_result=validate_job_result)

    class Handler(BaseHTTPRequestHandler):
        server_version = "BenchmarkRadar"
        sys_version = ""

        def log_message(self, format, *args):
            # Request targets may contain credentials or control characters.
            pass

        def _reply(self, status, body, content_type="application/json; charset=utf-8", head=False, content_encoding=None):
            if not isinstance(body, bytes):
                body = json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
            # Dynamic interactive results can be as large as a snapshot. Honor
            # the same negotiation without expanding prepared gzip responses.
            accepted = self.headers.get('Accept-Encoding', '').lower().split(',')
            use_gzip = any(item.strip() == 'gzip' or item.strip().startswith('gzip;')
                           and not re.search(r'q\s*=\s*0(?:\.0*)?(?:\s*;|\s*$)', item) for item in accepted)
            if (content_encoding is None and content_type.startswith('application/json')
                    and len(body) >= 65536 and use_gzip):
                body = gzip.compress(body, compresslevel=1, mtime=0)
                content_encoding = 'gzip'
            self.send_response(status)
            self.send_header("X-Radar-Client-Version", "radar-chart-workspace-v9")
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            if content_encoding:
                self.send_header("Content-Encoding", content_encoding)
            if snapshot_bytes_provider is not None:
                self.send_header("X-Radar-Snapshot-Reader", "precomputed-v2")
            if snapshot_bytes_provider is not None or content_type.startswith('application/json'):
                self.send_header("Vary", "Accept-Encoding")
            if task_score_bytes_provider is not None and self.path == '/api/task-score':
                self.send_header('X-Radar-Task-Scorer', 'prepared-evidence-v1')
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            scripts = ["'self'"]
            if content_type.startswith('text/html'):
                for script in re.findall(r'<script\b[^>]*>(.*?)</script\s*>', body.decode('utf-8'), re.I | re.S):
                    scripts.append("'sha256-" + base64.b64encode(sha256(script.encode('utf-8')).digest()).decode('ascii') + "'")
            self.send_header("Content-Security-Policy", "default-src 'none'; script-src " + ' '.join(scripts) + "; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            if not head:
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    pass

        def _get(self, head=False):
            try:
                parts = urlsplit(self.path)
                path = unquote(parts.path, errors="strict")
                if parts.scheme or parts.netloc or "\\" in path or "\x00" in path or any(p in {".", ".."} for p in path.split("/")) or "%" in path:
                    self._reply(400, {"error": "invalid_request_path"}, head=head)
                    return
            except (UnicodeError, ValueError):
                self._reply(400, {"error": "invalid_request_path"}, head=head)
                return
            if path.startswith('/api/interactive-jobs/') and not parts.query:
                token = path.rsplit('/', 1)[-1]
                value = jobs.get(token) if re.fullmatch(r'[A-Za-z0-9_-]{43}', token) else None
                self._reply(200 if value else 404, value or {'error': 'job_expired_or_unknown'}, head=head)
                return
            if path == "/":
                self._reply(200, TASK_WORKSPACE_PAGE.encode("utf-8"), "text/html; charset=utf-8", head=head)
                return
            if path == "/classic":
                self._reply(200, _DASHBOARD.encode("utf-8"), "text/html; charset=utf-8", head=head)
                return
            if path == "/benchmark":
                self._reply(200, _BENCHMARK_PAGE.encode("utf-8"), "text/html; charset=utf-8", head=head)
                return
            if path == "/api/taxonomy" and not parts.query:
                self._reply(200, {"taxonomy": TAXONOMY, "templates": BUILTIN_PROFILES,
                    "task_profile_available": callable(task_profile_provider)}, head=head)
                return
            if path == '/api/task-measurements' and not parts.query:
                try:
                    from .catalog_task_scoring import prepare_inputs
                    from .task_measurements import projection
                    with lock:
                        source=snapshot_provider()
                        revision=source.get('snapshot_id') or source.get('generated_at')
                        if revision not in measurement_cache:
                            task_index,task_catalog=prepare_inputs(source['index'],source['benchmarks'],source.get('observations'))
                            value=projection(task_index,task_catalog,source.get('snapshot_id'))
                            measurement_cache.clear();measurement_cache[revision]=value
                        value=measurement_cache[revision]
                    self._reply(200,value,head=head)
                except Exception:
                    self._reply(503,{'error':'task_measurements_unavailable'},head=head)
                return
            if path == "/api/benchmark":
                try:
                    query = parse_qs(parts.query, strict_parsing=True)
                    if (set(query) != {"paper_id", "benchmark_id"}
                            or any(len(values) != 1 or len(values[0]) > 200 or not values[0]
                                   for values in query.values())):
                        raise ValueError("invalid benchmark identity")
                    if snapshot_bytes_provider is not None:
                        try:
                            body, encoding = snapshot_bytes_provider(('benchmark', query['paper_id'][0], query['benchmark_id'][0]), False)
                        except KeyError:
                            self._reply(404, {'error': 'not_found'}, head=head)
                            return
                        self._reply(200, body, head=head, content_encoding=encoding)
                        return
                    with lock:
                        snapshot = deepcopy(snapshot_provider())
                    detail = benchmark_detail(snapshot, query["paper_id"][0], query["benchmark_id"][0])
                except ValueError:
                    self._reply(400, {"error": "invalid_benchmark_identity"}, head=head)
                    return
                except SnapshotNotReady:
                    self._reply(503, {"error": "snapshot_initializing", "state": "INITIALIZING", "stale": True}, head=head)
                    return
                except Exception:
                    self._reply(503, {"error": "snapshot_unavailable", "state": "UNAVAILABLE", "stale": True}, head=head)
                    return
                self._reply(200, _public(detail), head=head) if detail else self._reply(404, {"error": "not_found"}, head=head)
                return
            routes = {"/api/overview": "overview", "/api/workspace": "workspace", "/api/status": "status", "/api/status/summary": "status", "/api/benchmarks": "benchmarks", "/api/observations": "observations", "/api/index": "index", "/api/task-index": "task_index", "/api/snapshot": None}
            if path not in routes:
                self._reply(404, {"error": "not_found"}, head=head)
                return
            if path == "/api/status/summary" and status_provider is not None:
                try:
                    # Queue diagnostics must not wait for full evidence projection.
                    body = json.dumps(_public_status_summary(status_provider()),
                                      ensure_ascii=False, allow_nan=False).encode("utf-8")
                except Exception:
                    self._reply(503, {"error": "status_unavailable", "state": "UNAVAILABLE", "stale": True}, head=head)
                    return
                self._reply(200, body, head=head)
                return
            if snapshot_bytes_provider is not None:
                from .snapshot_transport import SnapshotRefreshing
                # Do not queue fast reads behind legacy projection/detail work.
                accepted = self.headers.get('Accept-Encoding', '').lower().split(',')
                use_gzip = any(item.strip() == 'gzip' or item.strip().startswith('gzip;')
                               and not re.search(r'q\s*=\s*0(?:\.0*)?(?:\s*;|\s*$)', item) for item in accepted)
                try:
                    body, encoding = snapshot_bytes_provider(routes[path], use_gzip)
                except SnapshotRefreshing:
                    self._reply(503, {"error": "snapshot_refreshing", "state": "REFRESHING", "stale": True}, head=head)
                    return
                except SnapshotNotReady:
                    self._reply(503, {"error": "snapshot_initializing", "state": "INITIALIZING", "stale": True}, head=head)
                    return
                except Exception:
                    self._reply(503, {"error": "snapshot_unavailable", "state": "UNAVAILABLE", "stale": True}, head=head)
                    return
                self._reply(200, body, head=head, content_encoding=encoding)
                return
            try:
                # One provider call and one detached serialization per request.
                with lock:
                    snapshot = deepcopy(snapshot_provider())
                meta = {key: snapshot[key] for key in ("snapshot_id", "generated_at", "window")}
                field = routes[path]
                result = snapshot if field is None or field in {"overview", "workspace"} else {**meta, **snapshot[field]} if field in {"status", "index", "task_index"} else {**meta, "items": snapshot[field]}
                if field == 'overview':
                    from .benchmark_progress import overview
                    result = overview(snapshot)
                elif field == 'workspace':
                    from .snapshot_wire import pack, FORMAT
                    result = {**meta, 'status': snapshot['status'], 'wire_format': FORMAT,
                        'payload': pack({'snapshot': {k:v for k,v in snapshot.items()
                            if k not in {'snapshot_id','generated_at','window','status'}}, 'status_arrays': {}})}
                if path == '/api/status/summary':
                    result = {key: value for key, value in result.items() if key != 'jobs'}
                body = json.dumps(_public(result), ensure_ascii=False, allow_nan=False).encode("utf-8")
            except SnapshotNotReady:
                self._reply(503, {"error": "snapshot_initializing", "state": "INITIALIZING", "stale": True}, head=head)
                return
            except Exception:
                self._reply(503, {"error": "snapshot_unavailable", "state": "UNAVAILABLE", "stale": True}, head=head)
                return
            self._reply(200, body, head=head)

        def do_GET(self):
            self._get()

        def do_HEAD(self):
            self._get(head=True)

        def _readonly(self):
            self._reply(405, {"error": "read_only"})

        def do_POST(self):
            if self.path == '/api/interactive-jobs':
                try:
                    size = int(self.headers.get('Content-Length', ''))
                    if self.headers.get('Transfer-Encoding') or not 0 < size <= 65536:
                        raise ValueError('invalid size')
                    data = json.loads(self.rfile.read(size).decode('utf-8'))
                    if not isinstance(data, dict) or set(data) not in ({'kind','payload'},{'kind','payload','request_id'}):
                        raise ValueError('invalid request')
                    kind, payload = data['kind'], data['payload']
                    if not isinstance(payload, dict): raise ValueError('invalid payload')
                    from .task_labels import validate_profile
                    from .task_scoring import _names
                    if kind == 'profile':
                        if set(payload) != {'description'} or not isinstance(payload['description'], str) or not 1 <= len(payload['description'].strip()) <= 12000:
                            raise ValueError('invalid description')
                        payload = {'description': payload['description'].strip()}
                    elif kind == 'score':
                        if set(payload) - {'profile', 'reference_models', 'candidate_models'}: raise ValueError('invalid payload')
                        payload = dict(payload, profile=validate_profile(payload['profile']),
                            reference_models=_names(payload.get('reference_models', []), 'reference_models'))
                        if payload.get('candidate_models') is not None: _names(payload['candidate_models'], 'candidate_models')
                    else: raise ValueError('invalid kind')
                    self._reply(202, jobs.submit(kind, payload, request_id=data.get('request_id')))
                except JobsFull:
                    self._reply(429, {'error': 'interactive_queue_full'})
                except (ValueError, TypeError, KeyError, UnicodeError):
                    self._reply(400, {'error': 'invalid_task_request'})
                return
            if self.path == "/api/task-profile" and callable(task_profile_provider):
                try:
                    size = int(self.headers.get("Content-Length", ""))
                    if self.headers.get("Transfer-Encoding") or not 0 < size <= 65536:
                        raise ValueError("invalid length")
                    payload = json.loads(self.rfile.read(size).decode("utf-8"))
                    if (not isinstance(payload, dict) or set(payload) != {"description"}
                            or not isinstance(payload["description"], str)
                            or not 1 <= len(payload["description"].strip()) <= 12000):
                        raise ValueError("invalid description")
                except (ValueError, UnicodeError, TypeError):
                    self._reply(400, {"error": "invalid_task_description"})
                    return
                if not profile_slots.acquire(blocking=False):
                    self._reply(429, {"error": "task_profile_busy"})
                    return
                from .interactive_profile import TaskProfileFailure
                try:
                    from .task_labels import validate_profile
                    profile = validate_profile(task_profile_provider(payload["description"].strip()))
                    if profile["description"] != payload["description"].strip():
                        raise ValueError("description changed")
                    self._reply(200, {"profile": _public(profile),
                        "note": "模型建议的权重可编辑；仅显式提交时调用模型，描述不写入任务库。"})
                except TimeoutError:
                    self._reply(504, {"error": "task_profile_timeout"})
                except TaskProfileFailure as exc:
                    self._reply(503, {"error": exc.code})
                except Exception:
                    self._reply(503, {"error": "task_profile_unavailable"})
                finally:
                    profile_slots.release()
                return
            if self.path != "/api/task-score" or task_score_provider is None:
                self._readonly()
                return
            try:
                size = int(self.headers.get("Content-Length", ""))
                if self.headers.get("Transfer-Encoding") or size <= 0:
                    raise ValueError("invalid length")
            except ValueError:
                self._reply(400, {"error": "invalid_request"})
                return
            if size > 65536:
                self._reply(413, {"error": "request_too_large"})
                return
            from .task_score_runtime import TaskScoreBusy
            from .snapshot_transport import SnapshotRefreshing
            body, encoding = None, None
            try:
                from .task_labels import validate_profile
                from .task_scoring import _names
                payload = json.loads(self.rfile.read(size).decode("utf-8"))
                if not isinstance(payload, dict) or set(payload) - {"profile", "reference_models", "candidate_models"}:
                    raise ValueError("invalid payload")
                if not isinstance(payload.get("profile"), dict):
                    raise ValueError("profile must be an object")
                profile = validate_profile(payload["profile"])
                refs = _names(payload.get("reference_models", []), "reference_models")
                candidates = payload.get("candidate_models")
                if candidates is not None:
                    candidates = _names(candidates, "candidate_models")
                if not score_slots.acquire(blocking=False):
                    self._reply(429, {"error": "task_score_busy"})
                    return
                try:
                    if task_score_bytes_provider is not None:
                        accepted = self.headers.get('Accept-Encoding', '').lower().split(',')
                        use_gzip = any(item.strip() == 'gzip' or item.strip().startswith('gzip;')
                            and not re.search(r'q\s*=\s*0(?:\.0*)?(?:\s*;|\s*$)', item) for item in accepted)
                        body, encoding = task_score_bytes_provider(profile, refs, candidates, use_gzip)
                    else:
                        snapshot = deepcopy(task_score_provider(profile, refs, candidates))
                finally:
                    score_slots.release()
                if body is None:
                    result = {key: snapshot[key] for key in ("snapshot_id", "generated_at", "window", "task_index")}
            except TaskScoreBusy:
                self._reply(429, {"error": "task_score_busy"})
                return
            except SnapshotRefreshing:
                self._reply(503, {"error": "snapshot_refreshing"})
                return
            except SnapshotNotReady:
                self._reply(503, {"error": "snapshot_initializing"})
                return
            except (ValueError, TypeError, KeyError, UnicodeError):
                self._reply(400, {"error": "invalid_task_request"})
                return
            except Exception:
                self._reply(503, {"error": "snapshot_unavailable", "state": "UNAVAILABLE", "stale": True})
                return
            self._reply(200, body, content_encoding=encoding) if body is not None else self._reply(200, _public(result))

        def do_DELETE(self):
            match = re.fullmatch(r'/api/interactive-jobs/([A-Za-z0-9_-]{43})', self.path)
            if not match:
                self._readonly()
                return
            value = jobs.cancel(match[1]) if match else None
            self._reply(200 if value else 404, value or {'error': 'job_expired_or_unknown'})

        do_PUT = do_PATCH = do_OPTIONS = do_TRACE = _readonly

    server = RadarHTTPServer((host, port), Handler)
    server.daemon_threads = True
    server.interactive_jobs = jobs
    original_close = server.server_close
    def close():
        jobs.close()
        original_close()
    server.server_close = close
    return server
