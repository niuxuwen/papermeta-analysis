import argparse,ast,contextlib,hashlib,json,os,sys,tempfile,time
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,ZIP_DEFLATED
if sys.version_info < (3,11):raise SystemExit('请使用现有服务的 Python 3.11+ 解释器，例如 .venv/bin/python；未安装任何文件')

def digest(b):return hashlib.sha256(b).hexdigest()
def safe(root,name):
 p=PurePosixPath(name)
 if p.is_absolute() or '\\' in name or ':' in name or any(s in ('..','.') for s in p.parts):raise ValueError('Invalid payload path')
 dest=root.joinpath(*p.parts)
 if not dest.resolve().is_relative_to(root) or any(q.is_symlink() for q in (dest,*dest.parents) if q!=root.parent):raise ValueError('Symlink or escaped payload path')
 return dest
def replace(p,b,mode=None):
 p.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.NamedTemporaryFile(dir=p.parent,prefix='.v116-',delete=False) as f:
  tmp=Path(f.name);f.write(b);f.flush();os.fsync(f.fileno())
 try:
  if mode is not None:os.chmod(tmp,mode)
  for attempt in range(6):
   try:os.replace(tmp,p);break
   except PermissionError:
    if attempt==5:raise
    time.sleep(.15*(attempt+1))
 finally:tmp.unlink(missing_ok=True)
@contextlib.contextmanager
def idle_lock(root):
 p=root/'data/service/.run.lock'
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('a+b') as f:
  if os.name=='posix':
   import fcntl
   try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
   except BlockingIOError:raise RuntimeError('服务仍占用运行目录；未安装任何文件')
  else:
   import msvcrt
   if p.stat().st_size==0:f.write(b'0');f.flush()
   f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
  try:yield
  finally:
   if os.name=='posix':fcntl.flock(f,fcntl.LOCK_UN)
def main():
 a=argparse.ArgumentParser(description='v116 code-only update; never replaces data or configuration')
 a.add_argument('--project',type=Path,default=Path.cwd());a.add_argument('--apply',action='store_true');a.add_argument('--rollback',type=Path)
 args=a.parse_args();root=args.project.resolve()
 if not (root/'radar.py').is_file() or not (root/'recent_benchmarks').is_dir():raise ValueError('请指定现有 benchmark-radar 项目')
 if args.rollback:
  with idle_lock(root),ZipFile(args.rollback) as z:
   meta=json.loads(z.read('BACKUP.json'))
   if meta['project']!=str(root):raise ValueError('Backup project differs')
   for name,info in meta['files'].items():
    p=safe(root,name)
    if info is None:p.unlink(missing_ok=True)
    else:replace(p,z.read('old/'+name),info['mode'])
  print('代码回滚完成；数据与配置未更改');return
 with ZipFile(sys.argv[0]) as z:
  meta=json.loads(z.read('MANIFEST.json'));payload={n:z.read('payload/'+n) for n in meta['files']}
 for name,b in payload.items():
  safe(root,name)
  if digest(b)!=meta['files'][name]:raise ValueError('Payload checksum mismatch: '+name)
  if name.endswith('.py'):ast.parse(b.decode('utf-8-sig'),filename=name)
 changes={n:b for n,b in payload.items() if not safe(root,n).is_file() or safe(root,n).read_bytes()!=b}
 conflicts=[n for n in changes if safe(root,n).exists() and digest(safe(root,n).read_bytes()) not in meta['baseline'].get(n,[])]
 if conflicts:raise ValueError('服务器代码与已发布 v108/v111 基线不符，未覆盖：'+', '.join(conflicts))
 print(json.dumps({'release':meta['release'],'verified_files':len(payload),'changed_files':len(changes),'project':str(root)},ensure_ascii=False))
 if not args.apply or not changes:return
 with (contextlib.nullcontext() if all(n.startswith('web/') for n in changes) else idle_lock(root)):
  # Recheck after obtaining the service lock to reject concurrent code updates.
  for n in changes:
   p=safe(root,n)
   if p.exists() and digest(p.read_bytes()) not in [*meta['baseline'].get(n,[]),meta['files'][n]]:raise ValueError('Concurrent change: '+n)
  stamp=time.strftime('%Y%m%d-%H%M%S')+'-'+str(os.getpid())
  backup=root/'deployment/backups'/('code-before-v116-'+stamp+'.zip');backup.parent.mkdir(parents=True,exist_ok=True)
  old={n:({'mode':safe(root,n).stat().st_mode & 0o777} if safe(root,n).exists() else None) for n in changes}
  with ZipFile(backup,'x',ZIP_DEFLATED) as z:
   z.writestr('BACKUP.json',json.dumps({'project':str(root),'files':old}))
   for n,info in old.items():
    if info is not None:z.writestr('old/'+n,safe(root,n).read_bytes())
  written=[]
  try:
   for n,b in changes.items():replace(safe(root,n),b,old[n]['mode'] if old[n] else 0o644);written.append(n)
   for n,b in payload.items():
    if safe(root,n).read_bytes()!=b:raise ValueError('Installed checksum mismatch: '+n)
  except BaseException:
   with ZipFile(backup) as z:
    for n in reversed(written):
     if old[n] is None:safe(root,n).unlink(missing_ok=True)
     else:replace(safe(root,n),z.read('old/'+n),old[n]['mode'])
   raise
  report=dict(release=meta['release'],backup=str(backup),changed_files=sorted(changes),model_calls=0,data_modified=False)
  replace(root/'deployment/v116-installed.json',json.dumps(report,ensure_ascii=False,indent=2).encode())
  print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
 try:main()
 except Exception as e:print('安装停止：'+str(e),file=sys.stderr);sys.exit(1)
