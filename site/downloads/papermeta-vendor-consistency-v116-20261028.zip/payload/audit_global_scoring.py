"""Independent source, weight, likelihood and display audit for global paired scores."""
import argparse
from collections import Counter,defaultdict
from hashlib import sha256
from itertools import combinations
import json,math
from pathlib import Path
from audit_relative_scoring import replay as source_replay


def replay(snapshot):
    return source_replay(snapshot,scoring='global')



def independent_target(g,a,b):
    ref=g['reference_profile'];method=ref['contrast_method']
    sign=1 if g['direction']=='higher' else -1
    delta=sign*(a['value_numeric']-b['value_numeric'])
    if method=='TWO_MODEL_ORDINAL_ONLY':
        assert ref['reference_count']==2 and ref['contrast_scale'] is None and ref['information_weight']==.5
        return .5 if not delta else .75 if delta>0 else .25
    unit=ref['contrast_scale']
    if method=='SOURCE_REFERENCE_SD':
        assert ref['reference_count']>=3
        assert unit==ref['standard_deviation']
    elif method=='VERIFIED_QUARTER_RANGE':
        from recent_benchmarks.score_normalization import validate_scale
        scale,error=validate_scale(g['score_scale'],g)
        assert not error and unit==(scale['upper_bound']-scale['lower_bound'])/4
    else:
        assert method=='SAME_SOURCE_PEER_SD' and ref['scale_source_groups']
    return 1/(1+math.exp(max(-700,min(700,-delta/unit)))) if unit else .5


def check_projection(setting,rows,models):
    """Independent rule reconstruction and convex projection KKT certificate."""
    recorded=setting['consensus_projection'];cohort=set(setting['reference_cohort'])
    pair_sources=defaultdict(lambda:defaultdict(list));papers=defaultdict(set)
    for g in rows:
        for s in g['scores']:papers[s['model_canonical']].add(g['paper_id'])
        scores=sorted((s for s in g['scores'] if s['model_canonical'] in cohort),key=lambda s:s['model_canonical'])
        key=g['paper_id'],g.get('benchmark_identity',g['benchmark_id'])
        for a,b in combinations(scores,2):
            pair_sources[a['model_canonical'],b['model_canonical']][key].append(independent_target(g,a,b))
    expected={}
    for (a,b),sources in pair_sources.items():
        means={k:math.fsum(v)/len(v) for k,v in sources.items()}
        if len({p for p,_ in means})<2:continue
        for sign,winner,loser in ((1,a,b),(-1,b,a)):
            decisive={p for (p,_),v in means.items() if sign*(v-.5)>.01}
            if len(decisive)>=2 and all(sign*(v-.5)>=-1e-12 for v in means.values()):
                expected[winner,loser]=means
    assert {(r['winner'],r['loser']) for r in recorded['rules']}==set(expected)
    assert len(recorded['rules'])==len(expected)==recorded['constraints']
    shifts=defaultdict(float);adjusted=recorded['projected_strengths'];base=recorded['base_strengths']
    assert set(adjusted)==set(base)==cohort
    for rule,dual in zip(recorded['rules'],recorded['dual_shifts']):
        a,b=rule['winner'],rule['loser'];source_means=expected[a,b]
        assert {(r['paper_id'],r['benchmark_identity']) for r in rule['sources']}==set(source_means)
        assert all(math.isclose(r['winner_target'],source_means[r['paper_id'],r['benchmark_identity']]
            if a<b else 1-source_means[r['paper_id'],r['benchmark_identity']],abs_tol=1e-12) for r in rule['sources'])
        assert adjusted[a]>=adjusted[b]-1e-8
        assert dual[0]<=1e-9 and dual[1]>=-1e-9
        assert abs(len(papers[a])*dual[0]+len(papers[b])*dual[1])<1e-7
        assert abs(len(papers[a])*dual[0]*(adjusted[a]-adjusted[b]))<1e-7
        shifts[a]+=dual[0];shifts[b]+=dual[1]
    for n in cohort:
        assert abs(adjusted[n]-base[n]+shifts[n])<1e-7
        assert base[n]==models[n]['bt_strength']
    center=math.fsum(adjusted.values())/len(cohort) if cohort else 0
    assert math.isclose(center,setting['consensus_center'],abs_tol=1e-10)


def check_vendor_projection(setting,rows,models):
    """Reconstruct repeated common-source rules and verify projection KKT."""
    from recent_benchmarks.public_model_registry import model_vendor
    recorded=setting['consensus_projection'];cohort=set(setting['reference_cohort'])
    sources=defaultdict(lambda:defaultdict(list));paper_identity={g['paper_id']:g.get('calibration_paper_identity','paper:'+g['paper_id'])for g in rows};seen=set()
    for g in rows:
        scores=sorted((s for s in g['scores']if s['model_canonical']in cohort),key=lambda s:s['model_canonical'])
        for a,b in combinations(scores,2):
            an,bn=a['model_canonical'],b['model_canonical'];vendor=model_vendor(an)['vendor']
            if vendor=='其他 / 厂商待确认'or vendor!=model_vendor(bn)['vendor']:continue
            fingerprint=(an,bn,*(repr(g.get(k,''))for k in ('paper_id','table_id','row_key','metric','direction','model_setting','comparison_key')),a['value_numeric'],b['value_numeric'])
            if fingerprint in seen:continue
            seen.add(fingerprint)
            delta=(a['value_numeric']-b['value_numeric'])*(1 if g['direction']=='higher'else -1)
            sources[an,bn][g['paper_id'],g.get('benchmark_identity',g['benchmark_id'])].append((independent_target(g,a,b),.5 if not delta else float(delta>0)))
    proposed={}
    for(a,b),benchmarks in sources.items():
        means={key:(sum(x for x,y in rows)/len(rows),sum(y for x,y in rows)/len(rows))for key,rows in benchmarks.items()}
        for sign,winner,loser in[(1,a,b),(-1,b,a)]:
            if any(sign*(p-.5)<-1e-10 or sign*(v-.5)<-1e-10 for p,v in means.values()):continue
            decisive={paper_identity[p]for(p,b),(y,v)in means.items()if sign*(y-.5)>.51-.5 and sign*(v-.5)>0}
            if len(decisive)<2:continue
            weakest=min(1-1e-12,max(1e-12,min(y if sign==1 else 1-y for y,v in means.values()if sign*(y-.5)>.51-.5)))
            proposed[winner,loser]=math.log(weakest/(1-weakest))
    adjacency=defaultdict(set)
    for a,b in proposed:adjacency[a].add(b)
    def reachable(start,end):
        seen=set();pending=[start]
        while pending:
            n=pending.pop()
            if n==end:return True
            if n not in seen:seen.add(n);pending.extend(adjacency[n]-seen)
        return False
    expected={key:v for key,v in proposed.items()if not reachable(key[1],key[0])}
    assert {(r['winner'],r['loser'])for r in recorded['rules']}==set(expected)
    adjusted,base=recorded['projected_strengths'],recorded['base_strengths'];shifts=defaultdict(float)
    assert set(base)==set(adjusted)==cohort
    for r,margin,dual in zip(recorded['rules'],recorded['minimum_margins'],recorded['dual_shifts']):
        a,b=r['winner'],r['loser'];slack=adjusted[a]-adjusted[b]-margin
        assert math.isclose(margin,recorded['margin_fraction']*expected[a,b],abs_tol=1e-10)
        assert slack>=-1e-8 and dual[0]<=1e-8 and dual[1]>=-1e-8
        assert abs(sum(dual))<1e-8 and abs(dual[0]*slack)<1e-6
        shifts[a]+=dual[0];shifts[b]+=dual[1]
    for n in cohort:
        assert abs(adjusted[n]-base[n]+shifts[n])<1e-7
        assert base[n]==models[n]['bt_strength']
    assert abs(sum(adjusted.values())-sum(base.values()))<1e-7


def check(index):
    from recent_benchmarks.public_model_registry import model_name_review_reason
    from recent_benchmarks.publication_quality import metric_role
    assert index['method']['opponent_adjusted'] and index['method']['version'] in (9,10,11,12,13)
    if index['method']['version'] >= 11:
        from recent_benchmarks.measurement_semantics import measurement_kind
        for group in index['groups']:
            assert group['measurement_kind'] == measurement_kind(metric_role(group['metric'],group.get('metric_role_context','')))
            if group['metric_role'] != 'PERFORMANCE':
                assert group.get('global_status') != 'CORE_READY'
    temporal = index['method'].get('temporal_scoring', {})
    modern = index['method']['version'] >= 10
    assert index['score_panels']==[]
    minimum=index['method']['min_benchmarks'];prior=index['method']['prior_strength']
    groups={g['group_id']:g for g in index['groups']}
    published=components=contests=0
    for setting in index['relative_reference_audit']['settings']:
        rows=[{**g,'scores':[s for s in g['scores'] if s['model_canonical'] in g['global_reference_models']]}
              for g in index['groups'] if g['model_setting']==setting['model_setting'] and g.get('global_status')=='CORE_READY']
        nb=Counter(g.get('benchmark_identity',g['benchmark_id']) for g in rows)
        pb,bp=defaultdict(set),defaultdict(set)
        pg=Counter((g['paper_id'],g.get('benchmark_identity',g['benchmark_id'])) for g in rows)
        for g in rows:
            b=g.get('benchmark_identity',g['benchmark_id'])
            pb[g['paper_id']].add(b);bp[b].add(g['paper_id'])
        base_weight=lambda g:1/(max(len(pb[g['paper_id']]),len(bp[g.get('benchmark_identity',g['benchmark_id'])]))*pg[g['paper_id'],g.get('benchmark_identity',g['benchmark_id'])]*(len(g['scores'])-1))
        task_mass=Counter()
        for g in rows:
            strata=g['task_balance_strata']
            if modern:
                from datetime import date
                meta = g['temporal_provenance']
                if temporal['enabled']:
                    age = (date.fromisoformat(temporal['as_of'])-date.fromisoformat(meta['release_date'])).days if meta['release_date'] else None
                    expected = .5+.5*2**(-age/temporal['half_life_days']) if age is not None and age>=0 else .5
                    assert math.isclose(g['temporal_weight'],expected,abs_tol=1e-12)
                else:
                    assert g['temporal_weight']==1.
            for task in strata:task_mass[task]+=base_weight(g)*(len(g['scores'])-1)/len(strata)*(g['temporal_weight'] if modern else 1.)
        factors={g['group_id']:(g['temporal_weight'] if modern else 1.)*sum(1/task_mass[t] for t in g['task_balance_strata'])/len(g['task_balance_strata']) for g in rows}
        peak=max(factors.values(),default=1)
        factors={k:v/peak for k,v in factors.items()}
        total=sum(base_weight(g)*(len(g['scores'])-1) for g in rows)
        prior_factor=sum(base_weight(g)*(len(g['scores'])-1)*factors[g['group_id']] for g in rows)/total if total else 1
        prior=index['method']['prior_strength']*prior_factor
        assert math.isclose(prior,setting['prior_strength'],abs_tol=1e-12)
        def old_weight_for(g):
            b=g.get('benchmark_identity',g['benchmark_id'])
            assert math.isclose(factors[g['group_id']],g['task_balance_factor'],abs_tol=1e-12)
            info=.5 if g['reference_profile']['contrast_method']=='TWO_MODEL_ORDINAL_ONLY' else 1
            return base_weight(g)*factors[g['group_id']]*info
        pair_counts=Counter();pair_pb=defaultdict(set);pair_bp=defaultdict(set)
        for g in rows:
            b=g.get('benchmark_identity',g['benchmark_id']);p=g['paper_id']
            for x,y in combinations(sorted(s['model_canonical'] for s in g['scores']),2):
                pair_counts[x,y,p,b]+=1;pair_pb[x,y,p].add(b);pair_bp[x,y,b].add(p)
        raw_weights={};old_mass=0.
        for g in rows:
            b=g.get('benchmark_identity',g['benchmark_id']);p=g['paper_id']
            for x,y in combinations(sorted(s['model_canonical'] for s in g['scores']),2):
                info=.5 if g['reference_profile']['contrast_method']=='TWO_MODEL_ORDINAL_ONLY' else 1
                raw_weights[g['group_id'],x,y]=factors[g['group_id']]*info/(
                    pair_counts[x,y,p,b]*max(len(pair_pb[x,y,p]),len(pair_bp[x,y,b])))
                old_mass+=old_weight_for(g)
        if index['method']['version'] >= 12:
            incident_paper,incident_bench=Counter(),Counter()
            for (gid,x,y),w in raw_weights.items():
                g=groups[gid];b=g.get('benchmark_identity',g['benchmark_id'])
                v=w/(factors[gid]*g['reference_profile']['information_weight'])
                for n in (x,y):incident_paper[n,g['paper_id']]+=v;incident_bench[n,b]+=v
            raw_weights={key:w/max(1.,incident_paper[key[1],groups[key[0]]['paper_id']],
                incident_paper[key[2],groups[key[0]]['paper_id']],
                incident_bench[key[1],groups[key[0]].get('benchmark_identity',groups[key[0]]['benchmark_id'])],
                incident_bench[key[2],groups[key[0]].get('benchmark_identity',groups[key[0]]['benchmark_id'])])
                for key,w in raw_weights.items()}
            bounded_paper,bounded_bench=Counter(),Counter()
            for (gid,x,y),w in raw_weights.items():
                for n in (x,y):
                    bounded_paper[n,groups[gid]['paper_id']]+=w
                    bounded_bench[n,groups[gid].get('benchmark_identity',groups[gid]['benchmark_id'])]+=w
            assert max(bounded_paper.values(),default=0)<=1+1e-12
            assert max(bounded_bench.values(),default=0)<=1+1e-12
        mass_scale=old_mass/math.fsum(raw_weights.values()) if raw_weights else 1.
        if index['method']['version'] < 12:assert mass_scale<=1+1e-12
        assert math.isclose(mass_scale,setting['source_weighting']['global_mass_scale'],abs_tol=1e-12)
        def weight_for(g,x,y):
            return raw_weights[g['group_id'],*sorted((x,y))]*mass_scale
        paper_budget,benchmark_budget=Counter(),Counter()
        models={m['model_canonical']:m for m in index['models'] if m['model_setting']==setting['model_setting']}
        primary=set(setting['primary_component'])
        latent=setting['latent_fit'];labels=latent['node_labels'];theta=latent['strengths'];prior_weights=latent['prior_weights']
        lookup={tuple(label):i for i,label in enumerate(labels)}
        assert len(labels)==len(theta)==len(prior_weights)==len(lookup)
        assert {label[1] for label in labels if label[0]=='GENERAL'}==primary
        expected_tasks={(s['model_canonical'],t) for g in rows for s in g['scores'] if s['model_canonical'] in primary for t in g['task_balance_strata']}
        assert {(label[1],label[2]) for label in labels if label[0]=='TASK'}==expected_tasks
        assert math.isclose(latent['coupling_weight'],prior_factor*index['method']['task_coupling_strength'],abs_tol=1e-12)
        gradient=[p*(1/(1+math.exp(-t))-.5) for p,t in zip(prior_weights,theta)]
        for i,label in enumerate(labels):
            if label[0]=='GENERAL':
                assert math.isclose(prior_weights[i],prior,abs_tol=1e-12)
                assert theta[i]==models[label[1]]['bt_strength']
            else:
                assert prior_weights[i]==0
                gi=lookup['GENERAL',label[1]];delta=latent['coupling_weight']*(1/(1+math.exp(theta[i]-theta[gi]))-.5)
                gradient[gi]+=delta;gradient[i]-=delta
        adjacency=defaultdict(set)
        for g in rows:
            from recent_benchmarks.publication_quality import metric_role
            assert metric_role(g['metric'], g.get('metric_role_context', '')) == 'PERFORMANCE'
            ref=g['reference_profile']
            if ref['contrast_method']=='SAME_SOURCE_PEER_SD':
                from statistics import median
                fields=('paper_id','table_id','benchmark_id','metric','model_setting','comparison_key','direction')
                peers=[other for other in rows if other['group_id']!=g['group_id']
                       and all(other.get(k,'')==g.get(k,'') for k in fields)
                       and other['reference_profile']['reference_count']>=3
                       and other['reference_profile']['standard_deviation']>0]
                assert set(ref['scale_source_groups'])=={p['group_id'] for p in peers}
                assert ref['contrast_scale']==median(p['reference_profile']['standard_deviation'] for p in peers)
            assert not g['blocked_reasons'] and not g.get('extraction_in_progress') and len(g['scores'])>=2
            b=g.get('benchmark_identity',g['benchmark_id'])
            expected_pairs={(a,c):weight_for(g,a,c) for a,c in combinations(sorted(s['model_canonical'] for s in g['scores']),2)}
            assert len(g['global_pair_weights'])==len(expected_pairs)
            for a,c,w in g['global_pair_weights']:assert math.isclose(w,expected_pairs[a,c],abs_tol=1e-12)
            assert math.isclose(g['global_pair_weight'],math.fsum(expected_pairs.values())/len(expected_pairs),abs_tol=1e-12)
            sign=1 if g['direction']=='higher' else -1
            for a,c in combinations(g['scores'],2):
                x,y=a['model_canonical'],c['model_canonical']
                weight=weight_for(g,x,y)
                pair=tuple(sorted((x,y)))
                paper_budget[g['paper_id'],*pair]+=weight
                benchmark_budget[b,*pair]+=weight
                adjacency[x].add(y);adjacency[y].add(x)
                if x not in primary:continue
                calibration=[s for s in groups[g['group_id']]['scores'] if s['model_canonical'] in g['reference_profile']['reference_models']]
                scale=max(abs(s['value_numeric']) for s in calibration) or 1.
                values=[s['value_numeric']/scale for s in calibration]
                mean=math.fsum(values)/len(values)
                sd=math.sqrt(math.fsum((v-mean)**2 for v in values)/len(values))
                ref=g['reference_profile']
                assert math.isclose(sd*scale,ref['standard_deviation'],rel_tol=1e-10,abs_tol=1e-10)
                observed=independent_target(g,a,c)
                for task in g['task_balance_strata']:
                    ai,bi=lookup['TASK',x,task],lookup['TASK',y,task]
                    fitted=1/(1+math.exp(theta[bi]-theta[ai]))
                    delta=weight/len(g['task_balance_strata'])*(fitted-observed)
                    gradient[ai]+=delta;gradient[bi]-=delta
                contests+=1
        if primary:
            seen=set();pending=[next(iter(primary))]
            while pending:
                x=pending.pop()
                if x in seen:continue
                seen.add(x);pending.extend(adjacency[x]-seen)
            assert seen==primary
        assert max(map(abs,gradient),default=0)<1e-6
        bound=max(1.,mass_scale) if index['method']['version']>=12 else 1.
        assert max(paper_budget.values(),default=0)<=bound+1e-12
        assert max(benchmark_budget.values(),default=0)<=bound+1e-12
        # Independently peel the source-incidence graph; verify maximal core,
        # rather than only checking whichever names the scorer selected.
        remaining={g['group_id']:{s['model_canonical'] for s in g['scores']} for g in rows}
        while True:
            bs,ps=defaultdict(set),defaultdict(set)
            for gid,names in remaining.items():
                for n in names:
                    bs[n].add(groups[gid].get('benchmark_identity',groups[gid]['benchmark_id']));ps[n].add(groups[gid]['paper_id'])
            admitted={n for n in bs if len(bs[n])>=minimum and len(ps[n])>=index['method']['min_source_papers']}
            updated={gid:ns&admitted for gid,ns in remaining.items() if len(ns&admitted)>=2}
            if updated==remaining:break
            remaining=updated
        assert set(setting['core_selection']['models'])==admitted
        cohort=setting['reference_cohort']
        expected_cohort=primary&admitted
        if len(expected_cohort)<2:expected_cohort=set()
        assert set(cohort)==expected_cohort
        center=math.fsum(models[n]['bt_strength'] for n in cohort)/len(cohort) if cohort else 0
        assert math.isclose(center,setting['center'],abs_tol=1e-12)
        for name,m in models.items():
            assert model_name_review_reason(name) is None
            benches=set()
            for c in m['score_components']:
                g=next(g for g in rows if g['group_id']==c['group_id']);b=g.get('benchmark_identity',g['benchmark_id'])
                s=next(s for s in g['scores'] if s['model_canonical']==name)
                assert c['raw_value']==s['value_numeric']
                assert set(c['observation_ids'])==set(s['observation_ids'])
                expected_weights={t['model_canonical']:weight_for(g,name,t['model_canonical']) for t in g['scores'] if t is not s}
                assert set(c['opponent_pair_weights'])==set(expected_weights)
                assert all(math.isclose(c['opponent_pair_weights'][n],w,abs_tol=1e-12) for n,w in expected_weights.items())
                assert math.isclose(c['pair_weight'],math.fsum(expected_weights.values())/len(expected_weights),abs_tol=1e-12)
                assert set(c['opponents'])=={s['model_canonical'] for s in g['scores'] if s['model_canonical']!=name}
                ys=[independent_target(g,s,t) for t in g['scores'] if t is not s]
                assert math.isclose(c['comparison_target'],sum(ys)/len(ys),abs_tol=1e-12)
                assert c['comparison_scale_sd']==g['reference_profile']['standard_deviation']
                assert c['comparison_method']==g['reference_profile']['contrast_method']
                assert c['task_strata']==g['task_balance_strata']
                if modern:
                    assert c['temporal_weight']==g['temporal_weight']
                    assert c['temporal_provenance']==g['temporal_provenance']
                benches.add(b);components+=1
            expected_heads={label[2]:theta[i] for i,label in enumerate(labels) if label[:2]==['TASK',name]}
            assert {t['task_stratum']:t['strength'] for t in m['fitted_task_strengths']}==expected_heads
            for t in m['fitted_task_strengths']:
                assert math.isclose(t['task_deviation'],t['strength']-m['bt_strength'],abs_tol=1e-12)
            assert len(benches)==m['scored_benchmarks']
            papers={c['paper_id'] for c in m['score_components']}
            eligible=name in cohort and m['core_benchmarks']>=minimum and m['core_source_papers']>=index['method']['min_source_papers'] and len(cohort)>=2 and setting['fit']['converged']
            assert eligible==m['publication_eligible']
            if not eligible:
                assert m['score'] is None and m['score_interval'] is None
                continue
            expected=100/(1+math.exp(-(m['bt_strength']-center)))
            assert math.isclose(expected,m['base_publication_score'],abs_tol=1e-9)
            if index['method']['version']>=13:
                corrected=m['source_consensus'];projected=setting['consensus_projection']['projected_strengths'][name]
                assert math.isclose(corrected['adjusted_strength'],projected,abs_tol=1e-10)
                display=round(100/(1+math.exp(-(projected-center))),6)
                assert m['score_uncertainty']['standard_error']>=m['bt_standard_error']
                score_se=m['score_uncertainty']['standard_error'];lo,hi=m['score_interval']
                assert math.isclose(lo,100/(1+math.exp(-(projected-center-1.96*score_se))),abs_tol=1e-9)
                assert math.isclose(hi,100/(1+math.exp(-(projected-center+1.96*score_se))),abs_tol=1e-9)
            elif modern:
                assert m['source_consensus'] is None
                assert setting['consensus_projection']['enabled'] is False
                assert setting['consensus_projection']['constraints']==0
                display=round(expected,6)
            else:
                corrected=m['source_consensus']
                projected=setting['consensus_projection']['projected_strengths'][name]
                assert math.isclose(corrected['adjusted_strength'],projected,abs_tol=1e-10)
                display=round(100/(1+math.exp(-(projected-setting['consensus_center']))),6)
            assert display==m['score'] and m['publication_score']==m['score']
            assert m['rank_interval'] is None
            if index['method']['version']<13:assert m['score_interval']==m['base_score_interval'] if modern else m['score_interval'] is None
            se=m['bt_standard_error'];lo,hi=m['base_score_interval']
            assert math.isclose(lo,100/(1+math.exp(-(m['bt_strength']-center-1.96*se))),abs_tol=1e-9)
            assert math.isclose(hi,100/(1+math.exp(-(m['bt_strength']-center+1.96*se))),abs_tol=1e-9)
            assert 0<=lo<=m['base_publication_score']<=hi<=100
            published+=1
        ordered=sorted((m for m in models.values() if m['publication_eligible']),key=lambda m:(-m['score'],m['model_canonical']))
        for i,m in enumerate(ordered):
            evidence=m['ranking_evidence']
            assert evidence['point_estimate_position']==i+1
            if not i:
                assert evidence['above_model'] is None and evidence['above_comparison'] is None
                continue
            opponent=ordered[i-1]['model_canonical'];assert evidence['above_model']==opponent
            same=defaultdict(list)
            for g in rows:
                values={s['model_canonical']:s['value_numeric'] for s in g['scores']}
                if m['model_canonical'] not in values or opponent not in values:continue
                delta=(values[m['model_canonical']]-values[opponent])*(1 if g['direction']=='higher' else -1)
                same[g.get('benchmark_identity',g['benchmark_id'])].append(.5 if not delta else float(delta>0))
            proof=evidence['above_comparison']
            assert proof['shared_benchmarks']==len(same)
            assert proof['shared_groups']==sum(map(len,same.values()))
            means=[sum(v)/len(v) for v in same.values()]
            assert proof['benchmark_wins']==sum(v>.5 for v in means)
            assert proof['benchmark_losses']==sum(v<.5 for v in means)
            assert proof['benchmark_ties']==sum(v==.5 for v in means)
            assert (proof['mean_win_fraction'] is None)==(not means)
        if index['method']['version']>=13:check_vendor_projection(setting,rows,models)
        elif not modern:check_projection(setting,rows,models)
    return dict(source_provenance='PASS',pair_weights='PASS',stationary_likelihood='PASS',
        source_paper_and_benchmark_budgets='PASS',task_macro_weights='PASS',shared_vs_task_strengths='PASS',penalties_not_source_edges='PASS',two_model_scale_policy='PASS',broad_coverage_admission='PASS',
        connected_reference='PASS',fixed_0_100_mapping='PASS',continuous_source_margin_objective='PASS',interval_mapping='PASS',adjacent_ranking_evidence='PASS',source_consensus_projection_kkt='VENDOR_ONLY_PASS'if index['method']['version']>=13 else 'REMOVED' if modern else 'PASS',
        checked_score_components=components,checked_pair_records=contests,published_models=published)


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snapshot',type=Path,default=Path('data/service/current.json'))
    p.add_argument('--output',type=Path,default=Path('data/logs/global-scoring-v97-audit.json'))
    args=p.parse_args(argv);original=args.snapshot.read_bytes();snapshot=json.loads(original.decode('utf-8-sig'))
    index=replay(snapshot);report=dict(input_sha256=sha256(original).hexdigest(),as_of=snapshot['generated_at'],
        input_observations=len(snapshot['observations']),method=index['method'],checks=check(index),
        published_models=index['automatic_scoring']['published_models'],model_calls=0,
        examples=sorted([dict(model=m['model_canonical'],setting=m['model_setting'],score=m['score'],
            interval=m['score_interval'],benchmarks=m['scored_benchmarks']) for m in index['models'] if m['publication_eligible']],key=lambda m:-m['score'])[:20],
        validation_scope='Real recorded source-gated results at their recorded as-of date, not a new paper reproduction or latest server audit.')
    assert args.snapshot.read_bytes()==original
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('真实成绩:',len(snapshot['observations']),'计分模型/设置:',report['published_models'],'来源/成对权重/联合拟合复算通过；API调用=0')
    return 0


if __name__=='__main__':raise SystemExit(main())
