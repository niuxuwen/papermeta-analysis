"""Read-only replay and independent arithmetic audit of a real published snapshot."""
import argparse
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path

from recent_benchmarks.indexing import build_index
from recent_benchmarks.relative_scoring import apply_relative_panels


def replay(snapshot, *, scoring='relative'):
    # The input is a recorded public, source-gated publication at its own as-of
    # instant. Do not relabel old data as today's live window.
    catalog = {(b['paper_id'], b['benchmark_id']): b for b in snapshot['benchmarks']}
    rows = [deepcopy(r) for r in snapshot['observations'] if not r.get('extraction_in_progress')
            and catalog.get((r.get('paper_id'), r.get('benchmark_id')), {}).get('eligibility') == 'ELIGIBLE']
    from recent_benchmarks.benchmark_identity import source_benchmark_identity
    for row in rows:
        row.pop('score_scale', None)
        identity = source_benchmark_identity(catalog[row['paper_id'], row['benchmark_id']])
        row.pop('benchmark_identity', None)
        if identity:
            row['benchmark_identity'] = identity
    minimum=snapshot.get('index',{}).get('method',{}).get('min_benchmarks',3)
    minimum=max(3,minimum) if type(minimum) is int else 3
    # A previous publication's derived admission threshold is not a persisted
    # user configuration. Replay the installed global policy, including an
    # upgrade from the old 10-benchmark publication rule back to the default 3.
    if scoring=='global':minimum=3
    index=build_index(rows,min_benchmarks=minimum)
    if scoring=='global':
        from recent_benchmarks.global_scoring import apply_global_scores
        return apply_global_scores(index,min_benchmarks=minimum,benchmark_catalog=snapshot['benchmarks'],as_of=snapshot.get('generated_at'))
    return apply_relative_panels(index,min_benchmarks=minimum)


def check(index):
    groups = {g['group_id']: g for g in index['groups']}
    checked_cells = checked_components = 0
    for group in groups.values():
        profile = group.get('reference_profile')
        if not profile:
            assert all('relative_score' not in s for s in group['scores'])
            continue
        values = [s['value_numeric'] for s in group['scores']]
        # Independent direct arithmetic, rather than calling the normalizer.
        mean = math.fsum(values)/len(values)
        std = math.sqrt(math.fsum((v-mean)**2 for v in values)/len(values))
        assert len(values) >= 3 and std > 0
        assert not group.get('blocked_reasons') and not group.get('extraction_in_progress')
        assert profile['reference_count'] == len(values)
        assert math.isclose(profile['mean'], mean, abs_tol=1e-10, rel_tol=1e-10)
        assert math.isclose(profile['standard_deviation'], std, abs_tol=1e-10, rel_tol=1e-10)
        sign = 1 if group['direction']=='higher' else -1
        for source in group['scores']:
            expected = sign*(source['value_numeric']-mean)/std
            assert math.isclose(source['relative_score'], expected, abs_tol=1e-9, rel_tol=1e-9)
            checked_cells += 1
        assert abs(math.fsum(s['relative_score'] for s in group['scores'])/len(values)) < 1e-9
    for panel in index['score_panels']:
        items = panel['items']
        assert len(items) == len({item['group_id'] for item in items})
        chosen = [groups[item['group_id']] for item in items]
        benchmarks = Counter(g.get('benchmark_identity', g['benchmark_id']) for g in chosen)
        assert len(benchmarks) >= 3
        assert len(panel['models']) >= 2
        assert math.isclose(math.fsum(i['weight'] for i in items), 1, abs_tol=1e-12)
        for item, group in zip(items, chosen):
            expected = 1/len(benchmarks)/benchmarks[group.get('benchmark_identity', group['benchmark_id'])]
            assert math.isclose(item['weight'], expected, abs_tol=1e-12)
            assert item['reference_id'] == group['reference_profile']['reference_id']
            assert group['model_setting'] == panel['model_setting']
        members = set.intersection(*(set(s['model_canonical'] for s in g['scores']) for g in chosen))
        assert members == set(panel['member_names'])
        for model in panel['models']:
            assert model['publication_eligible'] and model['score_panel_id']==panel['panel_id']
            components = model['score_components']
            assert len(components)==len(items) and not model['missing_score_groups']
            for component in components:
                group = groups[component['group_id']]
                source = next(s for s in group['scores'] if s['model_canonical']==model['model_canonical'])
                assert component['raw_value']==source['value_numeric']
                assert component['normalized_score']==source['relative_score']
                assert set(component['observation_ids'])==set(source['observation_ids'])
                assert math.isclose(component['contribution'], component['weight']*source['relative_score'], abs_tol=1e-12)
                checked_components += 1
            assert math.isclose(model['publication_score'], math.fsum(c['contribution'] for c in components), abs_tol=1e-12)
    return {'arithmetic':'PASS','missing_and_scope_checks':'PASS','checked_reference_cells':checked_cells,
            'checked_score_components':checked_components}


def audit_file(path, output):
    raw = path.read_bytes()
    snapshot = json.loads(raw.decode('utf-8-sig'))
    index = replay(snapshot)
    checks = check(index)
    catalog = {(b['paper_id'], b['benchmark_id']): b for b in snapshot['benchmarks']}
    examples = []
    for panel in index['score_panels'][:3]:
        example = {'name':panel['name'],'panel_id':panel['panel_id'],'models':[]}
        for model in sorted(panel['models'], key=lambda m:-m['publication_score'])[:3]:
            components = [{**c, 'benchmark_name':catalog[c['paper_id'], c['benchmark_id']]['benchmark_name']}
                          for c in model['score_components']]
            example['models'].append({'model':model['model_canonical'],'relative_index':model['publication_score'],
                                      'components':components})
        examples.append(example)
    report = {'schema_version':'relative-scoring-replay-v1','input_sha256':sha256(raw).hexdigest(),
        'input_snapshot_id':snapshot.get('snapshot_id'),'as_of':snapshot.get('generated_at'),
        'input_observations':len(snapshot['observations']),'input_benchmarks':len(snapshot['benchmarks']),
        'model_records':len(index['models']),'score_groups':len(index['groups']),
        'reference_counts':index['relative_reference_audit']['counts'],**index['automatic_scoring'],
        'checks':checks,'examples':examples,'model_calls':0,
        'validation_scope':'Replay of recorded, source-gated published raw results; not independent paper reproduction or server deployment.'}
    assert path.read_bytes()==raw, 'Input snapshot changed during audit'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    return report, index


def main(argv=None):
    parser = argparse.ArgumentParser(description='离线回放真实发布快照并独立复算相对指数；不调用API、不改队列或原成绩。')
    parser.add_argument('--snapshot', type=Path, default=Path(__file__).resolve().parent/'data/service/current.json')
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'data/logs/relative-scoring-v93-audit.json')
    args = parser.parse_args(argv)
    report, _ = audit_file(args.snapshot, args.output)
    print('真实快照回放：成绩',report['input_observations'],'参考组',report['reference_counts'].get('READY',0),
          '独立集合',report['panels'],'可在对应集合比较的模型',report['published_models'])
    print('独立复算与缺测检查：PASS；API调用=0；输入快照未修改。')
    print('报告：',args.output.resolve())
    if not report['panels']:
        print('当前真实数据未形成共同集合，原因见报告；不会编造指数。')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
