"""Minimal same-vendor score calibration from repeated common-source evidence.

This is a declared consistency constraint on the score, not a new observation
or proof of universal model dominance. Release order is never consulted.
"""
from collections import defaultdict
from itertools import combinations
from statistics import fmean
import math
import re
from .public_model_registry import model_vendor
from .relative_scoring import _benchmark

POLICY='repeated-source-vendor-consistency-v1'
MIN_PAPERS=2
DECISIVE=.51
MARGIN_FRACTION=.5
CALIBRATION={'policy':'whole-source-family-vendor-consistency-v116','source_snapshot':'4454273dd745c7e7aa3d7712',
    'folds':4,'source_families':171,'candidates':[0.,.05,.1,.25,.5,1.],
    'selected_margin':MARGIN_FRACTION,'selection':'Minimum held-out macro-source soft-comparison logloss; training evidence alone constructs constraints.',
    'base_metrics':{'soft_logloss':.6763976642700276,'logloss':.6358653414191603,'brier':.2138086128726034,'direction_agreement':.6552594834488409},
    'selected_metrics':{'soft_logloss':.6735162960638991,'logloss':.6335822534090532,'brier':.21271256757936696,'direction_agreement':.6464218804015118},
    'limitations':['Development selection on one observational snapshot; not independent external validation.',
        'Probability losses improved on average; directional agreement decreased by about 0.9 percentage points.',
        'Consistency constraints are an explicit scoring assumption conditional on shared measured tasks, not universal dominance.']}

def attach_paper_identities(groups,catalog):
    by={(b['paper_id'],b['benchmark_id']):b for b in catalog or []}
    for g in groups:
        b=by.get((g['paper_id'],g['benchmark_id']),{});arxiv=b.get('arxiv_id')
        g['calibration_paper_identity']='arxiv:'+re.sub(r'v\d+$','',arxiv)if isinstance(arxiv,str)and re.fullmatch(r'\d{4}\.\d{4,5}(?:v\d+)?',arxiv)else 'paper:'+g['paper_id']

def rules_from_sources(groups,names,target):
    names=set(names);vendors={n:model_vendor(n)['vendor']for n in names}
    sources=defaultdict(lambda:defaultdict(list));paper_identity={g['paper_id']:g.get('calibration_paper_identity','paper:'+g['paper_id'])for g in groups};seen=set()
    for g in groups:
        rows=sorted((s for s in g['scores']if s['model_canonical']in names),key=lambda s:s['model_canonical'])
        for a,b in combinations(rows,2):
            an,bn=a['model_canonical'],b['model_canonical']
            if vendors[an]!=vendors[bn]or vendors[an]=='其他 / 厂商待确认':continue
            fingerprint=(an,bn,*(repr(g.get(k,''))for k in ('paper_id','table_id','row_key','metric','direction','model_setting','comparison_key')),a['value_numeric'],b['value_numeric'])
            if fingerprint in seen:continue
            seen.add(fingerprint)
            delta=(a['value_numeric']-b['value_numeric'])*(1 if g['direction']=='higher'else -1)
            sources[an,bn][g['paper_id'],_benchmark(g)].append((target(g,a,b),.5 if delta==0 else float(delta>0),g['group_id']))
    rules=[]
    for(a,b),benchmarks in sorted(sources.items()):
        means={key:(fmean(r[0]for r in rows),fmean(r[1]for r in rows))for key,rows in benchmarks.items()}
        for sign,winner,loser in [(1,a,b),(-1,b,a)]:
            if any(sign*(p-.5)<-1e-10 or sign*(v-.5)<-1e-10 for p,v in means.values()):continue
            decisive={paper_identity[paper]for(paper,bench),(p,v)in means.items()if sign*(p-.5)>DECISIVE-.5 and sign*(v-.5)>0}
            if len(decisive)<MIN_PAPERS:continue
            positive=[p if sign==1 else 1-p for p,v in means.values()if sign*(p-.5)>DECISIVE-.5]
            weakest=min(1-1e-12,max(1e-12,min(positive)))
            rules.append({'winner':winner,'loser':loser,'vendor':vendors[a],'source_papers':len({paper_identity[p]for p,b in means}),
                'decisive_papers':len(decisive),'shared_benchmarks':len(means),
                'weakest_source_effect':math.log(weakest/(1-weakest)),
                'sources':[{'paper_id':p,'paper_identity':paper_identity[p],'benchmark_identity':b,'winner_target':y if sign==1 else 1-y,
                    'winner_win_fraction':v if sign==1 else 1-v,'group_ids':[r[2]for r in benchmarks[p,b]]}for(p,b),(y,v)in sorted(means.items())]})
    return rules

def cyclic_components(rules):
    adjacency=defaultdict(list);reverse=defaultdict(list);nodes=set()
    for r in rules:
        a,b=r['winner'],r['loser'];adjacency[a].append(b);reverse[b].append(a);nodes.update([a,b])
    seen=set();order=[]
    def visit(n):
        if n in seen:return
        seen.add(n)
        for x in adjacency[n]:visit(x)
        order.append(n)
    for n in sorted(nodes):visit(n)
    seen=set();parts=[]
    def collect(n,part):
        if n in seen:return
        seen.add(n);part.append(n)
        for x in reverse[n]:collect(x,part)
    for n in reversed(order):
        if n not in seen:
            part=[];collect(n,part)
            if len(part)>1:parts.append(sorted(part))
    return sorted(parts)

def calibrate(strengths,groups,eligible,target,*,margin_fraction=0.):
    if not 0<=margin_fraction<=1:raise ValueError('Invalid observed margin fraction')
    names=sorted(set(eligible)&strengths.keys());pos={n:i for i,n in enumerate(names)}
    proposed=rules_from_sources(groups,names,target);cycles=cyclic_components(proposed)
    cycle={n:i for i,c in enumerate(cycles)for n in c}
    rules=[r for r in proposed if r['winner']not in cycle or cycle.get(r['winner'])!=cycle.get(r['loser'])]
    base=[strengths[n]for n in names];values=base[:];shifts=[[0.,0.]for r in rules]
    margins=[margin_fraction*r['weakest_source_effect']for r in rules]
    pairs=[(pos[r['winner']],pos[r['loser']])for r in rules]
    error=0.;violation=0.
    for iteration in range(1,10001):
        previous=values[:]
        for i,((a,b),margin)in enumerate(zip(pairs,margins)):
            za,zb=values[a]+shifts[i][0],values[b]+shifts[i][1]
            if za-zb<margin:
                correction=(margin-za+zb)/2;va,vb=za+correction,zb-correction
            else:va,vb=za,zb
            shifts[i]=[za-va,zb-vb];values[a],values[b]=va,vb
        error=max((abs(a-b)for a,b in zip(previous,values)),default=0.)
        violation=max((values[b]+m-values[a]for(a,b),m in zip(pairs,margins)),default=0.)
        if error<1e-10 and violation<1e-8:break
    else:raise ArithmeticError('Vendor consistency calibration did not converge')
    # The local derivative of the Euclidean projection averages each connected
    # active block. Conditional uncertainty can propagate this linear contrast.
    parent=list(range(len(names)))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for(a,b),margin in zip(pairs,margins):
        if abs(values[a]-values[b]-margin)<1e-7:parent[find(a)]=find(b)
    blocks=defaultdict(list)
    for i,n in enumerate(names):blocks[find(i)].append(n)
    coefficients={n:{member:1/len(block)for member in block}for block in blocks.values()for n in block}
    result=dict(strengths);result.update(zip(names,values))
    assert abs(math.fsum(values)-math.fsum(base))<1e-7
    audit={'policy':POLICY,'enabled':True,'minimum_source_papers':MIN_PAPERS,'decisive_target':DECISIVE,
        'margin_fraction':margin_fraction,'constraints':len(rules),'rules':rules,'conflicting_cycles':cycles,
        'skipped_cycle_rules':len(proposed)-len(rules),'iterations':iteration,'max_change':error,
        'max_constraint_violation':max(0.,violation),'changed_models':sum(abs(x-y)>1e-7 for x,y in zip(base,values)),
        'squared_distance':math.fsum((x-y)**2 for x,y in zip(base,values)),
        'active_blocks':[b for b in blocks.values()if len(b)>1],
        'base_strengths':dict(zip(names,base)),'projected_strengths':dict(zip(names,values)),
        'minimum_margins':margins,'dual_shifts':shifts,
        'interpretation':'Minimal score consistency calibration within a source-backed vendor, requiring >=2 independently decisive papers and no opposing common-source benchmark mean. No release-order assumptions. Cyclic evidence is retained as conflict and not forced into equal scores. Margins are a calibrated fraction of the weakest observed source contrast.'}
    return result,audit,coefficients
