"""Exact-source measurement roles, protocol scope and task strata.

Retains original values and identities. Recover only existing source-audited
capability strata; flag task modes rather than infer a setting from a name.
"""
import re
from copy import deepcopy
from collections import Counter

POLICY = 'source-role-protocol-context-v119'


def normalized(value):
    return ' '.join(str(value or '').split()).casefold()


def source_role(group, benchmark):
    """A caption alone is insufficient to establish a model-as-target axis."""
    ctx = normalized(group.get('metric_role_context'))
    quote = normalized(benchmark.get('evidence_quote'))
    exact_binding = (group.get('paper_id'), group.get('benchmark_id')) == (
        benchmark.get('paper_id'), benchmark.get('benchmark_id'))
    if (exact_binding and ctx and ctx in quote
            and re.search(r'\bunderlying model\s*\|', quote)
            and re.search(r'\battribution performance\b.*\bidentity spoofing\b', ctx)):
        return {'role': 'TARGET_MODEL_DIAGNOSTIC', 'basis': 'EXACT_CAPTION_AND_UNDERLYING_MODEL_AXIS',
                'quote': benchmark['evidence_quote'], 'caption': group['metric_role_context']}
    label = normalized(group.get('metric')).rstrip('↑↓').strip()
    if (re.fullmatch(r'(?:gain|improvement|delta)', label)
            and re.search(r'\b(?:inference settings?|non[- ]thinking|thinking modes?)\b', ctx)
            and re.search(r'\b' + re.escape(label) + r'\s+is\s+(?:its|the)\s+difference\s+from\b', ctx)):
        return {'role': 'INTERVENTION_EFFECT', 'basis': 'EXPLICIT_CONDITION_DIFFERENCE_DEFINITION',
                'quote': group['metric_role_context']}
    return None


def recover_strata(group, benchmark):
    """No topic guessed from a model/benchmark name, title, or result value."""
    if group.get('task_balance_strata') != ['unclassified']:
        return None
    if (group.get('paper_id'), group.get('benchmark_id')) != (
            benchmark.get('paper_id'), benchmark.get('benchmark_id')):
        return None
    source = {'paper_id': group['paper_id'], 'benchmark_id': group['benchmark_id']}
    if source not in benchmark.get('catalog_label_sources', []):
        return None
    enrichment = benchmark.get('enrichment', {}).get('labels', {})
    if enrichment.get('status') != 'SUPPORTED':
        return None
    supported = set(benchmark.get('catalog_labels', {}).get('capabilities', []))
    direct = {'visual_perception': 'visual', 'video_understanding': 'visual',
              'audio_understanding': 'audio', 'reading_comprehension': 'language_documents',
              'long_context': 'language_documents', 'privacy': 'safety', 'safety': 'safety'}
    evidence = [e for e in enrichment.get('evidence', [])
                if e.get('layer') == 'capabilities' and e.get('id') in direct
                and e.get('id') in supported and e.get('bound_to_benchmark') is True
                and isinstance(e.get('quote'), str) and e['quote'].strip()]
    if not evidence:
        return None
    return {'strata': sorted({direct[e['id']] for e in evidence}),
            'basis': 'SOURCE_AUDITED_CAPABILITY_WITHOUT_TASK_TAXONOMY_MATCH',
            'source': source,
            'evidence': [{k: e[k] for k in ('id', 'source_id', 'quote') if k in e} for e in evidence]}


def inference_condition(group):
    ctx = normalized(group.get('metric_role_context'))
    label = normalized(group.get('metric'))
    if group.get('model_setting'):
        return None
    if label in {'zs', 'cot', 'zs+d', 'tree', 'tree+d'} and re.search(
            r'\bzero[- ]shot\b|\bchain[- ]of[- ]thought\b', ctx):
        return {'status': 'SETTING_REPORTED_ON_METRIC_AXIS', 'source_label': group['metric'],
                'quote': group['metric_role_context']}
    if label == 'non-thinking' and 'inference settings' in ctx:
        return {'status': 'SETTING_REPORTED_ON_METRIC_AXIS', 'source_label': group['metric'],
                'quote': group['metric_role_context']}
    if re.search(r'\bunder standard \(non[- ]thinking\) inference\b', ctx):
        return {'status': 'UNIFORM_NON_THINKING_CAPTION', 'source_label': 'non-thinking',
                'quote': group['metric_role_context']}
    return None



def attach_source_context(index, catalog, *, recover_tasks=True):
    """Annotate the scoring copy; retain raw identities, values and settings."""
    by = {(b['paper_id'], b['benchmark_id']): b for b in catalog or []}
    audit = {'policy': POLICY, 'measurement_roles': [], 'recovered_tasks': [], 'conditions': []}
    for group in index.get('groups', []):
        for key in ('source_role_annotation', 'source_inference_condition', 'source_condition_key',
                    'task_balance_recovery','task_budget_strata'):
            group.pop(key, None)
        benchmark = by.get((group['paper_id'], group['benchmark_id']), {})
        if role := source_role(group, benchmark):
            proof = {**role, **{k: group[k] for k in ('group_id', 'paper_id', 'benchmark_id', 'table_id', 'metric')}}
            group['source_role_annotation'] = proof
            audit['measurement_roles'].append(proof)
        if recover_tasks and (recovery := recover_strata(group, benchmark)):
            # A recovered metadata label is not additional source evidence.
            # Keep its pre-recovery macro budget; only the task-fit head changes.
            # Fully audited taxonomy tasks retain their original fixed budgets.
            group['task_budget_strata'] = list(group['task_balance_strata'])
            group['task_balance_strata'] = recovery['strata']
            group['task_balance_source'] = [group['paper_id'], group['benchmark_id']]
            group['task_balance_recovery'] = recovery
            audit['recovered_tasks'].append({'group_id': group['group_id'], **recovery})
        if condition := inference_condition(group):
            label = normalized(condition['source_label'])
            group['source_inference_condition'] = condition
            group['source_condition_key'] = 'source:' + label
            audit['conditions'].append({'group_id': group['group_id'], **condition})
    index['source_context_audit'] = audit
    return audit


def resolved_role(group):
    """Recheck transported source-role proofs before trusting their role."""
    from .publication_quality import metric_role
    proof = group.get('source_role_annotation') or {}
    if all(proof.get(k) == group.get(k) for k in ('paper_id', 'benchmark_id', 'table_id', 'metric')):
        benchmark = {'paper_id': group.get('paper_id'), 'benchmark_id': group.get('benchmark_id'),
                     'evidence_quote': proof.get('quote', '')}
        checked = source_role(group, benchmark)
        if checked and checked['role'] == proof.get('role'):
            return checked['role']
    return metric_role(group['metric'], group.get('metric_role_context', ''))


def global_condition_exclusion(group):
    """Explicit secondary inference settings remain source results, not defaults."""
    condition = group.get('source_inference_condition') or {}
    if condition.get('status') != 'SETTING_REPORTED_ON_METRIC_AXIS':
        return None
    label = normalized(condition.get('source_label'))
    if label in {'cot', 'zs+d', 'tree', 'tree+d', 'non-thinking'}:
        return 'explicit_secondary_inference_condition'
    return None
