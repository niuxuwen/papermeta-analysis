"""Bind coding-task references to caption-supported outcomes, never all cells."""
import re

POLICY='source-scoped-task-measurements-v1'


def attribute(group, benchmark, profile):
    requested=set(benchmark['matched_capabilities'])
    context=' '.join(str(group.get('metric_role_context')or'').split())
    metric=re.sub(r'[↑↓%()\s.]+','',str(group['metric'])).casefold()
    text=context.casefold()
    if 'code_development'not in profile['tasks']:
        return sorted(requested),'BENCHMARK_LEVEL_REFERENCE',None
    if re.search(r'summarizer backbone|continuation agent|recurring.detail retention|task preservation damage',text):
        return [],'AUXILIARY','summarizer_or_compaction_not_coding_agent'
    if metric=='ldpr':
        return [],'AUXILIARY','metric_meaning_not_established_by_source_caption'
    caps=set()
    quotes='\n'.join(str(e.get('quote')or'')for e in benchmark.get('label_evidence',[])).casefold()
    if 'domain abbreviations denote'in text and 'software work'in text:
        if metric not in {'soft','software'}:
            return [],'AUXILIARY','other_domain_or_mixed_domain_result'
        # Broad software-deliverable outcome proxy, not unit-test correctness.
        caps={'code_correctness'}
    elif 'implementation score'in str(group['metric']).casefold() and ('acceptance testing'in quotes or 'code acceptance'in quotes):
        caps={'code_correctness'}
    elif metric=='fs' and ('functional'in text or 'functional score'in quotes):
        caps={'code_correctness'}
    elif metric=='rs' and ('requirement satisfaction'in text or 'requirement satisfaction'in quotes):
        caps={'instruction_following'}
    elif metric=='residual' and 'residual reports success'in text:
        caps={'code_correctness','code_debugging'}
    elif metric.startswith('scalebench') and 'pass@1'in quotes and 'rtl'in quotes:
        caps={'code_correctness'}
    elif metric.startswith('banorm') and 'verifier generation'in quotes:
        caps={'code_correctness'}
    elif metric in {'accuracy','successrate'} and 'code acceptance'in text:
        caps={'code_correctness'}
    elif 'reasoning'in text and ('reasoning'in str(group['metric']).casefold() or metric=='accuracy'):
        caps={'reasoning'}
    elif metric in {'tpr','tnr','fprh'}:
        return [],'AUXILIARY','verifier_component_not_overall_coding_outcome'
    chosen=sorted(caps&requested)
    return (chosen,'SOURCE_SCOPED_TASK_OUTCOME',None)if chosen else ([], 'AUXILIARY','no_metric_level_task_binding')
