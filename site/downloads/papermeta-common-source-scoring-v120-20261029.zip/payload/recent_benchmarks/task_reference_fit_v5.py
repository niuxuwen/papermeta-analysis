"""Independent capability references: no cross-head mixing or missing-value fill."""
from collections import defaultdict
from itertools import combinations
from statistics import fmean
from .balanced_scoring import source_weights, comparison_core
from .global_scoring import prepare_contests, comparison_target
from .publication_quality import general_model_issue
from .source_balanced_scoring import incident_source_weights
from .source_consensus import pair_weight
from .shared_task_scoring import fit_graph
from .paired_scoring import sigmoid, components
from .scoring_preparation import digest


def fit_references(work, matched):
    by_setting,counts=prepare_contests(work);result={};audits=[]
    for setting,available in sorted(by_setting.items()):
        all_groups=[{**g,'scores':[s for s in g['scores']if not general_model_issue(s['model_canonical'])]}
                    for g in available]
        all_names=sorted({s['model_canonical']for g in all_groups for s in g['scores']})
        estimates=defaultdict(dict);component_keys=defaultdict(list)
        cap_ids=sorted({c for g in all_groups for c in g['metric_capabilities']})
        for cap in cap_ids:
            groups=[{**g,'task_balance_factor':1.}for g in all_groups if cap in g['metric_capabilities']]
            names=sorted({s['model_canonical']for g in groups for s in g['scores']});pos={n:i for i,n in enumerate(names)}
            base=source_weights(groups)
            weights=incident_source_weights(groups,{g['group_id']:base[g['group_id']]*g['reference_profile'].get('information_weight',1.)for g in groups})
            edges=[]
            for g in groups:
                for a,b in combinations(sorted(g['scores'],key=lambda s:s['model_canonical']),2):
                    edges.append((pos[a['model_canonical']],pos[b['model_canonical']],comparison_target(g,a,b),pair_weight(weights,g['group_id'],a['model_canonical'],b['model_canonical'])))
            theta,info=fit_graph({'edges':edges,'priors':[.3]*len(names)})
            if not info['converged']:raise ArithmeticError('Independent task fit did not converge')
            partitions=components(names,[(names[a],names[b],y,w)for a,b,y,w in edges])
            _,core=comparison_core(groups);broad=set(core['models'])
            for partition in partitions:
                anchors=[n for n in partition if n in broad]or partition
                center=fmean(theta[pos[n]]for n in anchors);identity=digest([setting,cap,partition])[:16]
                for name in partition:
                    estimates[name][cap]=100*sigmoid(theta[pos[name]]-center)
                    component_keys[name].append((cap,identity))
            audits.append({'model_setting':setting,'capability_id':cap,'models':len(names),'groups':len(groups),
                           'components':len(partitions),'fit':info,'source_weighting':weights.audit})
        for name in all_names:
            if not estimates[name]:continue
            result[name,setting]={'capabilities':estimates[name],
                'component':digest([setting,sorted(component_keys[name])])[:16],
                'reference_models':all_names,'shared_strength':None,'fit':{'converged':True}}
        for g in available:g['global_status']='CORE_READY'
    return result,{'policy':'independent-source-scoped-capability-v2','neutral_prior_strength':.3,
        'task_coupling_strength':0.,'capability_residual_mix':1.,'settings':audits,'counts':counts,
        'weight_policy':'Weights aggregate finished independent estimates; changing weights alone never refits estimates.',
        'missing_data':'No imputation. Separate cohorts by measured capability mask and source graph.',
        'model_calls':0}
