"""Source-bound task strata and honest low-reference contrast scales.

No model name, score, vendor or model release date determines task weights.
Benchmark recency is normalized inside source-bound task strata. Missing task
labels have their own visible stratum; no outcomes are imputed.
"""
from collections import Counter, defaultdict
from statistics import fmean, median
import math

from .score_normalization import validate_scale

TASK_STRATA = {
    'code_development': 'software',
    'knowledge_qa': 'knowledge',
    'mathematical_problem_solving': 'reasoning_data',
    'data_analysis': 'reasoning_data',
    'visual_document_understanding': 'visual',
    'interactive_execution': 'agents', 'tool_workflow': 'agents', 'planning': 'agents',
    'reading_comprehension': 'language_documents', 'document_qa': 'language_documents',
    'structured_extraction': 'language_documents', 'information_retrieval': 'language_documents',
    'dialogue': 'language_documents', 'writing': 'language_documents',
    'summarization': 'language_documents',
}


def attach_task_strata(index, catalog):
    """Only exact paper/benchmark source bindings; never infer from a name."""
    by_source = {(b['paper_id'], b['benchmark_id']): b for b in catalog or []}
    for g in index['groups']:
        b = by_source.get((g['paper_id'], g['benchmark_id']), {})
        # Public catalog labels have already passed the catalog's source audit.
        labels = b.get('catalog_labels', {}).get('tasks', []) if b.get('catalog_label_sources') else []
        labels = sorted({t for t in labels if t in TASK_STRATA})
        g['task_balance_labels'] = labels
        g['task_balance_strata'] = sorted({TASK_STRATA[t] for t in labels}) or ['unclassified']
        g['task_balance_source'] = [g['paper_id'], g['benchmark_id']] if labels else None


def prepare_contrast_scales(groups):
    """A two-value SD cannot establish a meaningful continuous margin.

    Prefer a verified range (quarter range as the fixed working contrast unit),
    otherwise a leave-group-out >=3-model SD from the exact same source,
    benchmark, metric, setting and comparison condition. Without either,
    expose an ordinal-only fallback with half information weight. Its target
    is .75/.25/.5, not a claim about the magnitude of the raw difference.
    """
    peers = defaultdict(list)
    def identity(g):
        return tuple(g.get(k, '') for k in ('paper_id', 'table_id', 'benchmark_id',
                     'metric', 'model_setting', 'comparison_key', 'source_condition_key', 'direction'))
    for g in groups:
        ref = g['reference_profile']
        if ref['reference_count'] >= 3 and ref['standard_deviation'] > 0:
            peers[identity(g)].append((g['group_id'], ref['standard_deviation']))
    for g in groups:
        ref = g['reference_profile']; sd = ref['standard_deviation']
        ref.update(contrast_scale=sd, contrast_method='SOURCE_REFERENCE_SD', information_weight=1., scale_source_groups=[])
        if ref['reference_count'] != 2:
            continue
        scale, _ = validate_scale(g.get('score_scale'), g)
        if scale and all(scale['lower_bound'] <= s['value_numeric'] <= scale['upper_bound'] for s in g['scores']):
            ref.update(contrast_scale=(scale['upper_bound']-scale['lower_bound'])/4,
                       contrast_method='VERIFIED_QUARTER_RANGE', scale_id=scale['scale_id'])
        elif candidates := [(gid, v) for gid, v in peers[identity(g)] if gid != g['group_id']]:
            ref.update(contrast_scale=median(v for _, v in candidates),
                       contrast_method='SAME_SOURCE_PEER_SD', scale_source_groups=[gid for gid, _ in candidates])
        else:
            ref.update(contrast_scale=None, contrast_method='TWO_MODEL_ORDINAL_ONLY', information_weight=.5)
        sign = 1 if g['direction'] == 'higher' else -1
        for s in g['scores']:
            ys=[]
            for t in g['scores']:
                if s is t: continue
                d=sign*(s['value_numeric']-t['value_numeric'])
                unit=ref['contrast_scale']
                ys.append((.5 if d==0 else .75 if d>0 else .25) if unit is None
                          else 1/(1+math.exp(max(-700,min(700,-d/unit)))) if unit else .5)
            s['comparison_target']=fmean(ys)


def task_weights(groups, base_weights):
    """Macro-average source losses over observed, source-labelled task strata.

    An incidence is split over its distinct strata, not duplicated per label.
    Source mass includes benchmark recency and ignores tested-model counts.
    A category's age alone cannot change its macro budget. All factors are <=1,
    preserving per-model paper and benchmark caps. The neutral prior is scaled
    by the source-mass mean factor, preserving its relative overall strength.
    Unlabelled sources remain an explicit stratum, not guessed capabilities.
    """
    mass=Counter(); budget={}; shares={}
    for g in groups:
        gid=g['group_id']; strata=g.get('task_budget_strata') or g.get('task_balance_strata') or ['unclassified']
        shares[gid]={s:1/len(strata) for s in strata}
        budget[gid]=base_weights[gid]*(len(g['scores'])-1)
        for s, fraction in shares[gid].items(): mass[s]+=budget[gid]*fraction*g.get('temporal_weight',1.)
    recency={g['group_id']:g.get('temporal_weight',1.) for g in groups}
    factors={gid:recency[gid]*sum(f/mass[s] for s,f in fractions.items()) for gid,fractions in shares.items()}
    maximum=max(factors.values(), default=1)
    factors={gid:f/maximum for gid,f in factors.items()}
    total=sum(budget.values())
    prior_factor=sum(budget[gid]*f for gid,f in factors.items())/total if total else 1.
    weights={g['group_id']:base_weights[g['group_id']]*factors[g['group_id']]
             *g['reference_profile'].get('information_weight',1.) for g in groups}
    for g in groups:
        g['task_balance_factor']=factors[g['group_id']]
    return weights, dict(stratum_source_mass=dict(sorted(mass.items())), prior_factor=prior_factor,
                         strata=len(mass), labelled_groups=sum('unclassified' not in shares[g['group_id']] for g in groups),
                         unclassified_groups=sum('unclassified' in shares[g['group_id']] for g in groups),
                         group_factors=factors)
