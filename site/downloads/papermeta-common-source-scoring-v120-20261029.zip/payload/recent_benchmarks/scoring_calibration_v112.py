"""Frozen development selection; no runtime tuning, model order, or API calls."""
CALIBRATION = {
    'policy': 'whole-source-family-budget-selection-v112',
    'source_snapshot': '28e1296cda118c5b688dc0ca',
    'source_sha256': 'cf950cbf6425dca3d7cc93f9d010b632df76d57613960e5f7495881586936de3',
    'protocol': 'Four held-out connected paper/benchmark-family folds. Recompute source budgets, training cohort and fitting inside each fold. Default settings only; all candidates receive the same audited task bindings.',
    'primary': 'macro-source soft-comparison logloss',
    'candidates': ['pair_p03_c3', 'cap_p03_c3', 'cap_p1_c3', 'cap_p03_c1'],
    'selected': 'cap_p03_c1', 'selected_prior': 0.3, 'selected_coupling': 1.0,
    'baseline': {'soft_logloss': 0.6742113077, 'logloss': 0.6312737821, 'brier': 0.2120274099, 'direction_agreement': 0.6516333195},
    'selected_metrics': {'soft_logloss': 0.6710461014, 'logloss': 0.6269917124, 'brier': 0.2100307697, 'direction_agreement': 0.6708815836},
    'limitations': ['Development comparison on one observational snapshot; not an independent external validation or statistical significance claim.',
                   'Coverage differs across models; sparse common-source evidence can still disagree with aggregate order.',
                   'Auxiliary repeat-support and direct-shared-evidence variants were inspected but are not used. No expected model-version order was optimized.',
                   'Task-reference scoring keeps its separate calibration; default-setting selection is not a validation of every experimental setting.'],
}
