"""Conservative discovery identities; source score and release IDs stay intact."""
from collections import defaultdict
from copy import deepcopy
from hashlib import sha256
import json
import re
import unicodedata
from urllib.parse import urlsplit, urlunsplit
from .catalog_label_state import supported_label_ids

VERSION = 'benchmark-discovery-identity-v2'


def name_key(value):
    # Only typography disappears. '+' and decimal/version punctuation remain.
    value = unicodedata.normalize('NFKC', value or '').casefold().replace('τ','tau')
    return re.sub(r'[\s_\-–—‑−]+', '', value)


def names(row):
    return {n.strip() for n in [row.get('benchmark_name', row.get('name', '')),
            *(row.get('benchmark_aliases', row.get('aliases', [])) or [])]
            if isinstance(n, str) and n.strip()}


def scope(row):
    """Do not erase versions, languages, named subsets, or variants."""
    name = row.get('benchmark_name', row.get('name', '')) or ''
    numeric = tuple(re.findall(r'\d+(?:\.\d+)*', name))
    variants = tuple(sorted(re.findall(
        r'(?i)(?<![a-z])(pro|plus|mini|lite|hard|easy|full|subset|test|train|dev|'
        r'english|chinese|en|zh|multilingual|verified)(?![a-z])', name.casefold())))
    fields = tuple(str(row.get(k) or '').strip().casefold() for k in
                   ('version', 'benchmark_version', 'subset', 'split', 'language'))
    return numeric, variants, fields, name.count('+')


def _resources(row):
    result = set()
    # Only source-extracted benchmark resources qualify, not paper URLs or a
    # shared publisher/domain. Network reachability alone is not identity proof.
    assets = (row.get('enrichment') or {}).get('assets') or {}
    for asset in assets.get('items', []):
        if not isinstance(asset, dict) or not asset.get('evidence_quote'):
            continue
        if str(asset.get('kind', '')).lower() not in {'dataset', 'code', 'repository', 'project', 'homepage'}:
            continue
        try:
            u = urlsplit(asset.get('url', ''))
            if u.scheme not in {'http', 'https'} or not u.hostname or u.username or u.password:
                continue
            path = u.path.rstrip('/')
            if not path or (u.hostname.casefold() in {'github.com', 'huggingface.co'} and path.count('/') < 2):
                continue
            # Keep query strings: they may identify a dataset/version.
            result.add(urlunsplit(('https', u.netloc.casefold(), path, u.query, '')))
        except ValueError:
            continue
    return result


def compatible(a, b):
    if any((r.get('name_audit') or {}).get('status')=='REVIEW_REQUIRED' for r in (a,b)):
        return False
    if a.get('identity_conflict') or b.get('identity_conflict') or scope(a) != scope(b):
        return False
    for key in ('release_date',):
        if (a.get(key) and b.get(key) and str(a[key])[:10] != str(b[key])[:10]
                and not a.get('date_basis') == b.get('date_basis') == 'PAPER_V1_PROXY'):
            return False
    overlap = {name_key(n) for n in names(a)} & {name_key(n) for n in names(b)}
    if not overlap:
        return False
    same_paper = bool(a.get('paper_id') and a.get('paper_id') == b.get('paper_id'))
    same_primary = name_key(a.get('benchmark_name', a.get('name', ''))) == name_key(b.get('benchmark_name', b.get('name', '')))
    # Same-paper formatting changes need no extra model judgment. Full-name /
    # acronym aliases must have already passed the source identity resolver.
    primary_names = [r.get('benchmark_name', r.get('name', '')) for r in (a,b)]
    alias_proof = any((r.get('identity_resolution') or {}).get('relation') == 'SAME'
        and all(re.search(r'(?<!\w)'+re.escape(' '.join(n.split()).casefold())+r'(?!\w)',
                         ' '.join(str((r.get('identity_resolution') or {}).get('evidence_quote','')).split()).casefold())
                for n in primary_names) for r in (a,b))
    # A shared repository may contain multiple datasets. Different primary
    # names need explicit alias proof as well as the resource match.
    return (same_paper and (same_primary or alias_proof)) or bool((same_primary or alias_proof) and _resources(a) & _resources(b))


def groups(rows):
    """Index exact normalized names/aliases; avoid quadratic fuzzy all-pairs."""
    buckets = defaultdict(list)
    for i, row in enumerate(rows):
        if (row.get('name_audit') or {}).get('status')=='REVIEW_REQUIRED':
            continue
        for name in names(row):
            buckets[name_key(name)].append(i)
    candidates = set()
    for bucket in buckets.values():
        for offset, i in enumerate(bucket):
            for j in bucket[offset+1:]:
                candidates.add((min(i,j), max(i,j)))
    clusters = {i:{i} for i in range(len(rows))}
    owners = list(range(len(rows)))
    for i, j in sorted(candidates):
        left, right = owners[i], owners[j]
        if left == right:
            continue
        # Complete-link guard: an alias bridge cannot collapse distinct versions
        # or independent benchmarks through transitive matching.
        if all(compatible(rows[a], rows[b]) for a in clusters[left] for b in clusters[right]):
            for index in clusters[right]: owners[index] = left
            clusters[left].update(clusters.pop(right))
    return [sorted(group) for group in clusters.values()]


def project_catalog(catalog):
    from .benchmark_name_hygiene import repair_catalog_names
    result = repair_catalog_names(catalog)
    for indices in groups(result):
        members = [result[i] for i in indices]
        identities = sorted({(str(r.get('paper_id') or ''), str(r.get('benchmark_id') or '')) for r in members})
        identifier = 'catalog-' + sha256(json.dumps(identities).encode()).hexdigest()[:24]
        originals = sorted({str(r.get('source_benchmark_name', r.get('benchmark_name', r.get('name', ''))) or '') for r in members})
        valid = [r['benchmark_name'] for r in members if (r.get('name_audit') or {}).get('status')!='REVIEW_REQUIRED']
        canonical = min(valid, key=lambda n:(len(n), n.casefold(), n)) if valid else members[0]['benchmark_name']
        shared = defaultdict(set)
        sources = []
        for r in members:
            labels = (r.get('enrichment') or {}).get('labels') or {}
            supported = {layer: supported_label_ids(labels,layer) for layer in ('domains','tasks','modalities','capabilities')}
            for layer in ('domains', 'tasks', 'modalities', 'capabilities'):
                shared[layer].update(supported.get(layer, []))
            if any(supported.values()):
                sources.append({'paper_id':r.get('paper_id'), 'benchmark_id':r.get('benchmark_id')})
        for r in members:
            r['source_benchmark_name'] = r.get('source_benchmark_name', r.get('benchmark_name', r.get('name', '')))
            r['benchmark_name'] = canonical
            r['catalog_identity'] = identifier
            r['catalog_aliases'] = originals
            r['catalog_sources'] = [dict(paper_id=p, benchmark_id=b) for p,b in identities]
            r['catalog_labels'] = {k:sorted(v) for k,v in shared.items()}
            r['catalog_label_sources'] = sources
    return result
