"""Source-bound distinction between task levels, condition effects and diagnostics.

Neither a delta glyph nor a bootstrap caption alone establishes a non-task
measurement. Definitions must connect a change to experimental conditions.
"""
import re
import unicodedata

POLICY = 'source-measurement-semantics-v3'


def declared_contrast_unit(group):
    """A source-declared unit, independent of the observed model roster.

    No range is inferred from observed minima/maxima. Mixed count/rate tables
    only supply a percentage unit for the explicitly marked rate column.
    This is a working contrast unit, not a statistical standard error.
    """
    metric=str(group.get('metric',''));ctx=str(group.get('metric_role_context',''))
    values=[s['value_numeric']for s in group.get('scores',[])]
    percent=('%' in metric or bool(re.search(r'(?i)(?:accuracy|weighted score|success)\s*\(%',ctx)))
    if re.search(r'(?i)\b(?:Pass is the number|Pass and %|% is Pass)\b',ctx) and '%'not in metric:
        percent=False
    if percent and values and all(0<=v<=100 for v in values):return 25.,'SOURCE_DECLARED_PERCENTAGE'
    if re.search(r'(?i)(?:scores?|values?|metrics?)\s+(?:are|in|range from)\s*(?:\[\s*)?0\s*[,–-]\s*1\b',ctx) and values and all(0<=v<=1 for v in values):
        return .25,'SOURCE_DECLARED_FRACTION'
    return None,None


def contrast_role(metric, context=''):
    label=unicodedata.normalize('NFKC',str(metric)).strip()
    ctx=unicodedata.normalize('NFKC',str(context)).replace('−','-')
    # Color difference is a final error objective, despite the delta glyph.
    if re.fullmatch(r'(?i)(?:[Δ∆]|delta)\s*E(?:\s*00|\s*2000)?\s*[↓↑]?',label) and re.search(r'(?i)\b(?:colou?r|CIEDE2000|colorimetric)\b',ctx):
        return None
    change_label=bool(re.search(r'[Δ∆]|\\[Dd]elta|(?i:\b(?:delta|gain|improvement|lift|difference|change)\b)',label))
    if not change_label:
        return None
    if (re.search(r'(?i)\b(?:inference settings?|non[- ]thinking|thinking modes?)\b', ctx)
            and re.search(r'(?i)\b(?:gain|improvement|delta)\s+is\s+(?:its|the)\s+difference\s+from\b', ctx)):
        return 'INTERVENTION_EFFECT'
    if re.search(r'(?i)\b(?:minus|margin over|relative to|gain per|effect per model)\b',ctx):
        return 'INTERVENTION_EFFECT'
    conditions=bool(re.search(r'(?i)\b(?:prompt(?:ing)?|implicit|explicit|intervention|treatment|ablation|augmentation|baseline|mitigation|fine[- ]?tun\w*|condition)s?\b',ctx+' '+label))
    definition=bool(re.search(r'(?i)\b(?:change|difference|improvement|gain)s?\s+(?:from|between|relative\s+to|over)\b|(?:[Δ∆]|\\Delta|\bdelta\b)\s*=|\b(?:relative\s+to|over|against)\s+(?:the\s+)?baseline\b|\bwith(?:out)?\b.{0,80}\bvs\.?\b',ctx+' '+label))
    if conditions and definition:
        return 'INTERVENTION_EFFECT'
    if re.search(r'(?i)\b(?:paired\s+model\s+comparisons?|differences?\s+between\s+models?|effect\s+sizes?)\b',ctx):
        return 'DERIVED_STATISTIC'
    return None


def measurement_kind(role):
    return {'PERFORMANCE':'FINAL_TASK_PERFORMANCE','INTERVENTION_EFFECT':'INTERVENTION_EFFECT',
        'STATISTIC':'STATISTICAL_DIAGNOSTIC','DERIVED_STATISTIC':'STATISTICAL_DIAGNOSTIC',
        'EFFICIENCY':'RESOURCE_MEASUREMENT','METADATA':'METADATA',
        'RELATIONAL_OR_DAMAGED_AXIS':'UNRESOLVED_AXIS','TARGET_MODEL_DIAGNOSTIC':'STATISTICAL_DIAGNOSTIC'}.get(role,'UNRESOLVED_AXIS')


def describe_group(group):
    from .source_comparison_context import resolved_role
    role=resolved_role(group)
    group.update(metric_role=role,measurement_kind=measurement_kind(role),measurement_policy=POLICY)
    return group


def restore_source_context(index, observations):
    """Rehydrate legacy published groups by exact observation IDs and source keys.

    No regrouping, guessed model identity, source promotion or value edits.
    Newly built indices already retain the same source-bound context.
    """
    by_id={r.get('observation_id'):r for r in observations if r.get('observation_id')}
    restored=0
    tables={}
    for row in observations:
        context=row.get('scope_evidence')
        if isinstance(context,str) and len(context.strip())>=80:
            tables.setdefault((row.get('paper_id'),row.get('table_id')),set()).add(context.strip())
    for group in index.get('groups',[]):
        contexts=set(tables.get((group['paper_id'],group['table_id']),()))
        for score in group['scores']:
            for oid in score.get('observation_ids',[]):
                row=by_id.get(oid,{})
                if (row.get('paper_id'),row.get('table_id'))!=(group['paper_id'],group['table_id']):continue
                if isinstance(row.get('scope_evidence'),str) and row['scope_evidence'].strip():contexts.add(row['scope_evidence'])
        if contexts:
            group['metric_role_context']='\n'.join(sorted(contexts));restored+=1
        describe_group(group)
    return {'policy':POLICY,'groups_with_exact_source_context':restored,'groups':len(index.get('groups',[]))}
