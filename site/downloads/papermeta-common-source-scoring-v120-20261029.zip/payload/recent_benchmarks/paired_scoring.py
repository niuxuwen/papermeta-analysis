"""Standard-library Bradley--Terry fit and benchmark-cluster uncertainty."""
import math


def sigmoid(x):
    if x >= 0:
        return 1/(1+math.exp(-x))
    e = math.exp(x)
    return e/(1+e)


def fit(n, edges, prior_strength=3.0, *, tolerance=1e-9, max_iterations=1500):
    """MM fit with explicit balanced pseudo-contests against neutral strength 0.

    Edges are (i,j,win_fraction_i,weight). The prior bounds separation but must
    never be used to connect otherwise disconnected source-evidence graphs.
    """
    if not math.isfinite(prior_strength) or prior_strength <= 0:
        raise ValueError('Neutral prior must be finite and positive')
    ratings, wins = [1.0]*n, [prior_strength/2]*n
    for a,b,y,w in edges:
        wins[a] += w*y
        wins[b] += w*(1-y)
    converged = False
    for iteration in range(1,max_iterations+1):
        denominator = [prior_strength/(r+1) for r in ratings]
        for a,b,_,w in edges:
            term = w/(ratings[a]+ratings[b])
            denominator[a] += term
            denominator[b] += term
        updated = [wins[i]/denominator[i] for i in range(n)]
        change = max((abs(math.log(updated[i]/ratings[i])) for i in range(n)),default=0)
        ratings = updated
        if change < tolerance:
            converged = True
            break
    theta = [math.log(r) for r in ratings]
    gradient = [prior_strength*(sigmoid(t)-.5) for t in theta]
    for a,b,y,w in edges:
        delta = w*(sigmoid(theta[a]-theta[b])-y)
        gradient[a] += delta
        gradient[b] -= delta
    error = max(map(abs,gradient),default=0)
    return theta,dict(converged=converged and error<1e-6,iterations=iteration,max_gradient=error)


def components(names,edges):
    adjacency = {n:set() for n in names}
    for a,b,_,_ in edges:
        adjacency[a].add(b)
        adjacency[b].add(a)
    result,seen = [],set()
    for start in sorted(names):
        if start in seen:
            continue
        pending,found = [start],set()
        seen.add(start)
        while pending:
            node = pending.pop()
            found.add(node)
            for other in sorted(adjacency[node]-seen):
                seen.add(other)
                pending.append(other)
        result.append(sorted(found))
    return result


def _solve(diagonal,curvature,rhs):
    def multiply(vector):
        out = [d*x for d,x in zip(diagonal,vector)]
        for a,b,v in curvature:
            delta = v*(vector[a]-vector[b])
            out[a] += delta
            out[b] -= delta
        return out
    jacobi = list(diagonal)
    for a,b,v in curvature:
        jacobi[a] += v
        jacobi[b] += v
    x,r = [0.0]*len(rhs),list(rhs)
    direction = [v/d for v,d in zip(r,jacobi)]
    product = math.fsum(a*b for a,b in zip(r,direction))
    for _ in range(max(40,len(rhs)*2)):
        if product < 1e-22:
            break
        h = multiply(direction)
        step = product/math.fsum(a*b for a,b in zip(direction,h))
        x = [v+step*p for v,p in zip(x,direction)]
        r = [v-step*p for v,p in zip(r,h)]
        z = [v/d for v,d in zip(r,jacobi)]
        updated = math.fsum(a*b for a,b in zip(r,z))
        if updated < 1e-22:
            break
        direction = [v+(updated/product)*p for v,p in zip(z,direction)]
        product = updated
    if max((abs(a-b) for a,b in zip(multiply(x),rhs)),default=0)>1e-6:
        raise ArithmeticError('Uncertainty solve did not converge')
    return x


def uncertainty(theta,edges,clusters,targets,prior_strength,*,contrasts=None,quadratic_edges=(),cluster_gradients=None):
    """Model-based approximate intervals, with a benchmark-cluster variance floor.

    Not guarantees under selective publication, domain shift or arbitrary
    missingness. The neutral prior supplies regularized information explicitly.
    """
    if not targets:
        return {}
    priors=([prior_strength]*len(theta) if isinstance(prior_strength,(int,float)) else prior_strength)
    diagonal = [p*sigmoid(t)*(1-sigmoid(t)) for p,t in zip(priors,theta)]
    curvature = []
    for a,b,_,w in edges:
        p = sigmoid(theta[a]-theta[b])
        curvature.append((a,b,w*p*(1-p)))
    for a,b,margin,w in quadratic_edges:
        if margin-theta[a]+theta[b]>0:
            curvature.append((a,b,w))
    result = {}
    for target in (contrasts if contrasts is not None else targets):
        rhs = [0.0]*len(theta)
        for i in targets:
            rhs[i] = -1/len(targets)
        for index,value in (contrasts[target].items() if contrasts is not None else [(target,1.)]):
            rhs[index] += value
        projected = _solve(diagonal,curvature,rhs)
        model = max(0.0,math.fsum(a*b for a,b in zip(rhs,projected)))
        cluster_gradients=cluster_gradients or {}
        influence = [math.fsum(w*(sigmoid(theta[a]-theta[b])-y)*(projected[a]-projected[b])
                      for a,b,y,w in clusters.get(key,[])) + math.fsum(d*(projected[a]-projected[b])
                      for a,b,d in cluster_gradients.get(key,[]))
                      for key in set(clusters)|set(cluster_gradients)]
        mean = math.fsum(influence)/len(influence) if influence else 0
        clustered = (len(influence)/(len(influence)-1)*math.fsum((v-mean)**2 for v in influence)) if len(influence)>1 else 0
        result[target] = dict(standard_error=math.sqrt(max(model,clustered)),model_variance=model,cluster_variance=clustered)
    return result
