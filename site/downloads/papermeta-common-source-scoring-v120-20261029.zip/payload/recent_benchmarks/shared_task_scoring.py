"""Joint general and task-specific strengths, with explicit partial pooling.

Only actual source comparisons connect different model identities. Task nodes
are regularized toward their own model's shared strength by balanced penalty
terms, not invented source observations. Missing tasks have no source nodes.
"""
from collections import defaultdict
import math

from .paired_scoring import sigmoid, _solve
from .source_consensus import pair_weight

COUPLING_STRENGTH = 3.0


def graph(names, groups, weights, target, neutral_prior, coupling_strength=COUPLING_STRENGTH, *, source_factor=1.):
    pos={n:i for i,n in enumerate(names)}
    tasks=sorted({(s['model_canonical'], t) for g in groups for s in g['scores']
                  if s['model_canonical'] in pos for t in g['task_balance_strata']})
    heads={key:len(names)+i for i,key in enumerate(tasks)}
    combined=defaultdict(lambda:[0.,0.]); clusters=defaultdict(list)
    for g in groups:
        rows=sorted((s for s in g['scores'] if s['model_canonical'] in pos),key=lambda s:s['model_canonical'])
        strata=g['task_balance_strata']
        for i,a in enumerate(rows):
            for b in rows[i+1:]:
                y=target(g,a,b)
                weight=pair_weight(weights,g['group_id'],a['model_canonical'],b['model_canonical'])/len(strata)
                for task in strata:
                    ai,bi=heads[a['model_canonical'],task],heads[b['model_canonical'],task]
                    combined[ai,bi][0]+=weight*y;combined[ai,bi][1]+=weight
                    clusters[g['paper_id']].append((ai,bi,y,weight))
    observed=[(a,b,wy/w,w) for (a,b),(wy,w) in sorted(combined.items())]
    # Both penalties use the same task-budget scale, preserving their ratio.
    coupling_weight=source_factor*coupling_strength
    penalties=[(pos[n],index,.5,coupling_weight) for (n,t),index in heads.items()]
    return dict(names=names,heads=heads,priors=[neutral_prior]*len(names)+[0.]*len(heads),
                observed_edges=observed,penalty_edges=penalties,edges=observed+penalties,
                clusters=dict(clusters),coupling_weight=coupling_weight,
                node_labels=[['GENERAL',n] for n in names]+[['TASK',n,t] for n,t in tasks])


def _softplus(x):
    return x+math.log1p(math.exp(-x)) if x>=0 else math.log1p(math.exp(x))


def objective(theta,edges,priors):
    return math.fsum(w*(_softplus(theta[a]-theta[b])-y*(theta[a]-theta[b])) for a,b,y,w in edges) + math.fsum(
        p*(_softplus(t)-.5*t) for p,t in zip(priors,theta) if p)


def fit_graph(layout, *, tolerance=1e-9, max_iterations=60):
    """Damped Newton/PCG fit; stdlib only, no server dependency additions."""
    edges,priors=layout['edges'],layout['priors'];theta=[0.]*len(priors)
    if not theta:return [],dict(converged=True,iterations=0,max_gradient=0.,solver='NEWTON_PCG')
    error=float('inf')
    quadratic=layout.get('quadratic_edges',[])
    def loss(v):
        return objective(v,edges,priors)+.5*math.fsum(w*max(0.,m-v[a]+v[b])**2 for a,b,m,w in quadratic)
    for iteration in range(1,max_iterations+1):
        gradient=[p*(sigmoid(t)-.5) for p,t in zip(priors,theta)]
        diagonal=[p*sigmoid(t)*(1-sigmoid(t)) for p,t in zip(priors,theta)]
        curvature=[]
        for a,b,y,w in edges:
            prob=sigmoid(theta[a]-theta[b]);d=w*(prob-y)
            gradient[a]+=d;gradient[b]-=d;curvature.append((a,b,w*prob*(1-prob)))
        for a,b,m,w in quadratic:
            residual=m-theta[a]+theta[b]
            if residual>0:
                gradient[a]-=w*residual;gradient[b]+=w*residual;curvature.append((a,b,w))
        error=max(map(abs,gradient))
        if error<tolerance:break
        step=_solve(diagonal,curvature,gradient)
        current=loss(theta);descent=math.fsum(a*b for a,b in zip(gradient,step))
        rate=1.
        while rate>=2**-30:
            updated=[t-rate*s for t,s in zip(theta,step)]
            if loss(updated)<=current-1e-4*rate*descent+1e-12:
                theta=updated;break
            rate/=2
        else:raise ArithmeticError('Shared-task fit line search failed')
    return theta,dict(converged=error<1e-7,iterations=iteration,max_gradient=error,
        solver='NEWTON_PCG_SQUARED_HINGE' if quadratic else 'NEWTON_PCG',regularization_terms=len(quadratic))
