"""Independent, evidence-backed discovery of recently introduced LLM benchmarks."""

VERSION = "recent-benchmarks-v1"
# The persisted run format stays compatible with v1; features have their own
# versions so a server update does not discard an existing discovery window.
CODE_VERSION = "benchmark-radar-source-audited-scoring-v119"
